/*
  # Initial schema for New Sonia Tent House

  1. New Tables
    - `clients`
      - `id` (uuid, primary key, linked to auth.users)
      - `created_at` (timestamp)
      - `email` (text, unique)
      - `phone` (text)
      - `full_name` (text)
      - `address` (text, nullable)
      - `preferences` (json, nullable)
      - `last_login` (timestamp, nullable)
    
    - `packages`
      - `id` (uuid, primary key)
      - `created_at` (timestamp)
      - `name` (text)
      - `description` (text)
      - `price` (numeric)
      - `features` (text array)
      - `image_url` (text, nullable)
      - `category` (text)
      - `is_popular` (boolean)
    
    - `inquiries`
      - `id` (uuid, primary key)
      - `created_at` (timestamp)
      - `client_id` (uuid, nullable, references clients.id)
      - `event_type` (text)
      - `guest_count` (integer)
      - `event_date` (date, nullable)
      - `budget_range` (text)
      - `message` (text, nullable)
      - `status` (text)
      - `recommended_package_id` (uuid, nullable, references packages.id)
    
    - `gallery`
      - `id` (uuid, primary key)
      - `created_at` (timestamp)
      - `title` (text)
      - `description` (text, nullable)
      - `image_url` (text)
      - `category` (text)
      - `tags` (text array, nullable)
  
  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Create clients table
CREATE TABLE IF NOT EXISTS clients (
  id uuid PRIMARY KEY REFERENCES auth.users,
  created_at timestamptz DEFAULT now(),
  email text UNIQUE NOT NULL,
  phone text NOT NULL,
  full_name text NOT NULL,
  address text,
  preferences jsonb,
  last_login timestamptz
);

-- Create packages table
CREATE TABLE IF NOT EXISTS packages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at timestamptz DEFAULT now(),
  name text NOT NULL,
  description text NOT NULL,
  price numeric NOT NULL,
  features text[] NOT NULL,
  image_url text,
  category text NOT NULL,
  is_popular boolean DEFAULT false
);

-- Create inquiries table
CREATE TABLE IF NOT EXISTS inquiries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at timestamptz DEFAULT now(),
  client_id uuid REFERENCES clients(id),
  event_type text NOT NULL,
  guest_count integer NOT NULL,
  event_date date,
  budget_range text NOT NULL,
  message text,
  status text DEFAULT 'new',
  recommended_package_id uuid REFERENCES packages(id)
);

-- Create gallery table
CREATE TABLE IF NOT EXISTS gallery (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at timestamptz DEFAULT now(),
  title text NOT NULL,
  description text,
  image_url text NOT NULL,
  category text NOT NULL,
  tags text[]
);

-- Enable Row Level Security
ALTER TABLE clients ENABLE ROW LEVEL SECURITY;
ALTER TABLE packages ENABLE ROW LEVEL SECURITY;
ALTER TABLE inquiries ENABLE ROW LEVEL SECURITY;
ALTER TABLE gallery ENABLE ROW LEVEL SECURITY;

-- Policies for clients table
CREATE POLICY "Users can view their own client data" 
  ON clients FOR SELECT 
  USING (auth.uid() = id);

CREATE POLICY "Users can update their own client data" 
  ON clients FOR UPDATE 
  USING (auth.uid() = id);

-- Policies for packages table (public read, admin write)
CREATE POLICY "Anyone can view packages" 
  ON packages FOR SELECT 
  TO authenticated, anon
  USING (true);

CREATE POLICY "Only admins can modify packages" 
  ON packages FOR ALL 
  TO authenticated
  USING (auth.jwt() ->> 'email' = 'admin@newsonia.com');

-- Policies for inquiries table
CREATE POLICY "Users can view their own inquiries" 
  ON inquiries FOR SELECT 
  USING (auth.uid() = client_id);

CREATE POLICY "Users can create inquiries" 
  ON inquiries FOR INSERT 
  WITH CHECK (auth.uid() = client_id);

CREATE POLICY "Admins can view all inquiries" 
  ON inquiries FOR SELECT 
  TO authenticated
  USING (auth.jwt() ->> 'email' = 'admin@newsonia.com');

-- Policies for gallery table (public read, admin write)
CREATE POLICY "Anyone can view gallery" 
  ON gallery FOR SELECT 
  TO authenticated, anon
  USING (true);

CREATE POLICY "Only admins can modify gallery" 
  ON gallery FOR ALL 
  TO authenticated
  USING (auth.jwt() ->> 'email' = 'admin@newsonia.com');

-- Sample data for packages
INSERT INTO packages (name, description, price, features, image_url, category, is_popular)
VALUES
  ('Basic Wedding Package', 'Perfect for intimate weddings with essential services', 50000, 
   ARRAY['Basic tent setup for up to 100 guests', 'Standard decoration', 'Basic catering (vegetarian options)', 'Seating arrangement', 'Basic lighting'],
   'https://images.pexels.com/photos/1616113/pexels-photo-1616113.jpeg', 'wedding', false),
  
  ('Premium Wedding Package', 'Elegant and comprehensive setup for your special day', 100000, 
   ARRAY['Deluxe tent setup for up to 200 guests', 'Elaborate decoration with floral arrangements', 'Premium catering (veg and non-veg options)', 'Customized seating arrangement', 'Enhanced lighting and sound system', 'Photography services', 'Valet parking'],
   'https://images.pexels.com/photos/1114425/pexels-photo-1114425.jpeg', 'wedding', true),
  
  ('Corporate Meeting Package', 'Professional setup for business meetings and seminars', 30000, 
   ARRAY['Tent setup for up to 50 participants', 'Professional seating arrangement', 'Basic catering with tea/coffee service', 'Projector and screen', 'Basic sound system', 'Wi-Fi connection'],
   'https://images.pexels.com/photos/2774556/pexels-photo-2774556.jpeg', 'corporate', false),
  
  ('Birthday Deluxe Package', 'Premium birthday party experience with all amenities', 40000, 
   ARRAY['Tent setup for up to 100 guests', 'Themed decoration with balloons and props', 'Premium catering with cake', 'DJ and entertainment', 'Photography services', 'Games and activities', 'Return gifts for guests'],
   'https://images.pexels.com/photos/7180795/pexels-photo-7180795.jpeg', 'birthday', true);

-- Sample data for gallery
INSERT INTO gallery (title, description, image_url, category, tags)
VALUES
  ('Elegant Wedding Setup', 'Complete wedding tent decoration for a grand ceremony', 
   'https://images.pexels.com/photos/1779414/pexels-photo-1779414.jpeg', 'wedding', 
   ARRAY['wedding', 'decoration', 'tent']),
  
  ('Corporate Meeting Arrangement', 'Professional setup for a corporate gathering', 
   'https://images.pexels.com/photos/2291367/pexels-photo-2291367.jpeg', 'corporate', 
   ARRAY['corporate', 'meeting', 'professional']),
  
  ('Birthday Party Decoration', 'Colorful setup for a birthday celebration', 
   'https://images.pexels.com/photos/4201748/pexels-photo-4201748.jpeg', 'birthday', 
   ARRAY['birthday', 'party', 'decoration']),
  
  ('Luxury Wedding Catering', 'Exquisite food presentation for a wedding reception', 
   'https://images.pexels.com/photos/7180795/pexels-photo-7180795.jpeg', 'wedding', 
   ARRAY['wedding', 'catering', 'food']),
  
  ('Engagement Ceremony', 'Beautiful setup for an engagement event', 
   'https://images.pexels.com/photos/1481117/pexels-photo-1481117.jpeg', 'engagement', 
   ARRAY['engagement', 'ceremony', 'decoration']),
  
  ('Cultural Event Setup', 'Traditional decoration for a cultural gathering', 
   'https://images.pexels.com/photos/6936034/pexels-photo-6936034.jpeg', 'cultural', 
   ARRAY['cultural', 'traditional', 'decoration']);