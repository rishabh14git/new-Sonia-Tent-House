import { motion } from 'framer-motion';
import { Star } from 'lucide-react';

interface TestimonialProps {
  testimonial: {
    id: number;
    name: string;
    role: string;
    testimonial: string;
    image: string;
    rating: number;
  };
}

const TestimonialCard = ({ testimonial }: TestimonialProps) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      viewport={{ once: true }}
      className="bg-white p-6 rounded-lg shadow-md"
    >
      <div className="flex items-center mb-4">
        <img 
          src={testimonial.image} 
          alt={testimonial.name} 
          className="w-12 h-12 rounded-full object-cover mr-4"
        />
        <div>
          <h3 className="font-semibold">{testimonial.name}</h3>
          <p className="text-sm text-gray-500">{testimonial.role}</p>
        </div>
      </div>
      
      <div className="flex mb-4">
        {Array.from({ length: 5 }).map((_, index) => (
          <Star 
            key={index} 
            size={16} 
            className={`${
              index < testimonial.rating 
                ? 'text-gold fill-gold' 
                : 'text-gray-300'
            }`} 
          />
        ))}
      </div>
      
      <p className="text-gray-600 italic">"{testimonial.testimonial}"</p>
    </motion.div>
  );
};

export default TestimonialCard;