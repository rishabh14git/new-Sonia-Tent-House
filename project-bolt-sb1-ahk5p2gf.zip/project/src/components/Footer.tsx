import { Link } from 'react-router-dom';
import { Facebook, Instagram, Mail, Phone, MapPin, Clock } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="container mx-auto py-12 px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* About */}
          <div>
            <h3 className="text-xl font-heading font-semibold mb-4 text-gold">New Sonia Tent House</h3>
            <p className="text-gray-300 mb-4">
              Providing premium tenting and catering services for all your special occasions in Delhi and the surrounding areas since 1990.
            </p>
            <div className="flex space-x-4 mt-4">
              <a 
                href="https://facebook.com" 
                target="_blank" 
                rel="noopener noreferrer"
                className="bg-maroon h-10 w-10 rounded-full flex items-center justify-center hover:bg-gold transition"
              >
                <Facebook size={20} />
              </a>
              <a 
                href="https://instagram.com" 
                target="_blank" 
                rel="noopener noreferrer"
                className="bg-maroon h-10 w-10 rounded-full flex items-center justify-center hover:bg-gold transition"
              >
                <Instagram size={20} />
              </a>
              <a 
                href="mailto:info@newsonia.com" 
                className="bg-maroon h-10 w-10 rounded-full flex items-center justify-center hover:bg-gold transition"
              >
                <Mail size={20} />
              </a>
            </div>
          </div>
          
          {/* Quick Links */}
          <div>
            <h3 className="text-xl font-heading font-semibold mb-4 text-gold">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/" className="text-gray-300 hover:text-gold transition inline-block py-1">
                  Home
                </Link>
              </li>
              <li>
                <Link to="/gallery" className="text-gray-300 hover:text-gold transition inline-block py-1">
                  Gallery
                </Link>
              </li>
              <li>
                <Link to="/packages" className="text-gray-300 hover:text-gold transition inline-block py-1">
                  Packages
                </Link>
              </li>
              <li>
                <Link to="/questionnaire" className="text-gray-300 hover:text-gold transition inline-block py-1">
                  Find Your Package
                </Link>
              </li>
              <li>
                <Link to="/contact" className="text-gray-300 hover:text-gold transition inline-block py-1">
                  Contact Us
                </Link>
              </li>
            </ul>
          </div>
          
          {/* Services */}
          <div>
            <h3 className="text-xl font-heading font-semibold mb-4 text-gold">Services</h3>
            <ul className="space-y-2">
              <li className="text-gray-300 hover:text-gold transition inline-block py-1">Wedding Tents</li>
              <li className="text-gray-300 hover:text-gold transition inline-block py-1">Corporate Events</li>
              <li className="text-gray-300 hover:text-gold transition inline-block py-1">Birthday Parties</li>
              <li className="text-gray-300 hover:text-gold transition inline-block py-1">Engagement Ceremonies</li>
              <li className="text-gray-300 hover:text-gold transition inline-block py-1">Catering Services</li>
              <li className="text-gray-300 hover:text-gold transition inline-block py-1">Decoration & Lighting</li>
            </ul>
          </div>
          
          {/* Contact Info */}
          <div>
            <h3 className="text-xl font-heading font-semibold mb-4 text-gold">Contact Us</h3>
            <ul className="space-y-4">
              <li className="flex items-start">
                <MapPin size={20} className="mr-2 text-gold flex-shrink-0 mt-0.5" />
                <span className="text-gray-300">
                  123 Market Street, New Delhi - 110001, India
                </span>
              </li>
              <li className="flex items-center">
                <Phone size={20} className="mr-2 text-gold flex-shrink-0" />
                <a href="tel:+911234567890" className="text-gray-300 hover:text-gold transition">
                  +91 123 456 7890
                </a>
              </li>
              <li className="flex items-center">
                <Mail size={20} className="mr-2 text-gold flex-shrink-0" />
                <a href="mailto:info@newsonia.com" className="text-gray-300 hover:text-gold transition">
                  info@newsonia.com
                </a>
              </li>
              <li className="flex items-start">
                <Clock size={20} className="mr-2 text-gold flex-shrink-0 mt-0.5" />
                <div className="text-gray-300">
                  <p>Monday - Saturday</p>
                  <p>10:00 AM - 8:00 PM</p>
                </div>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-800 mt-12 pt-6 text-center text-gray-400">
          <p>&copy; {new Date().getFullYear()} New Sonia Tent House. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;