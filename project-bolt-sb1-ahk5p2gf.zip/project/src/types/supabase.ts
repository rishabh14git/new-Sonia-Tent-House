export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      clients: {
        Row: {
          id: string
          created_at: string
          email: string
          phone: string
          full_name: string
          address: string | null
          preferences: Json | null
          last_login: string | null
        }
        Insert: {
          id?: string
          created_at?: string
          email: string
          phone: string
          full_name: string
          address?: string | null
          preferences?: Json | null
          last_login?: string | null
        }
        Update: {
          id?: string
          created_at?: string
          email?: string
          phone?: string
          full_name?: string
          address?: string | null
          preferences?: Json | null
          last_login?: string | null
        }
      }
      packages: {
        Row: {
          id: string
          created_at: string
          name: string
          description: string
          price: number
          features: string[]
          image_url: string | null
          category: string
          is_popular: boolean
        }
        Insert: {
          id?: string
          created_at?: string
          name: string
          description: string
          price: number
          features: string[]
          image_url?: string | null
          category: string
          is_popular?: boolean
        }
        Update: {
          id?: string
          created_at?: string
          name?: string
          description?: string
          price?: number
          features?: string[]
          image_url?: string | null
          category?: string
          is_popular?: boolean
        }
      }
      inquiries: {
        Row: {
          id: string
          created_at: string
          client_id: string | null
          event_type: string
          guest_count: number
          event_date: string | null
          budget_range: string
          message: string | null
          status: string
          recommended_package_id: string | null
        }
        Insert: {
          id?: string
          created_at?: string
          client_id?: string | null
          event_type: string
          guest_count: number
          event_date?: string | null
          budget_range: string
          message?: string | null
          status?: string
          recommended_package_id?: string | null
        }
        Update: {
          id?: string
          created_at?: string
          client_id?: string | null
          event_type?: string
          guest_count?: number
          event_date?: string | null
          budget_range?: string
          message?: string | null
          status?: string
          recommended_package_id?: string | null
        }
      }
      gallery: {
        Row: {
          id: string
          created_at: string
          title: string
          description: string | null
          image_url: string
          category: string
          tags: string[] | null
        }
        Insert: {
          id?: string
          created_at?: string
          title: string
          description?: string | null
          image_url: string
          category: string
          tags?: string[] | null
        }
        Update: {
          id?: string
          created_at?: string
          title?: string
          description?: string | null
          image_url?: string
          category?: string
          tags?: string[] | null
        }
      }
    }
  }
}