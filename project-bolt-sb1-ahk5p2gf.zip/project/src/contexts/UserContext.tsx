import { createContext, useContext, ReactNode } from 'react';
import { Session, User } from '@supabase/supabase-js';
import { supabase } from '../lib/supabase';

interface UserContextProps {
  session: Session | null;
  user: User | null;
  signOut: () => Promise<void>;
  isAdmin: boolean;
}

const UserContext = createContext<UserContextProps | undefined>(undefined);

export function UserProvider({ 
  children, 
  session 
}: { 
  children: ReactNode;
  session: Session | null;
}) {
  const user = session?.user || null;
  
  // In a real app, you might check user metadata or roles from your database
  // For simplicity, we'll assume any logged-in user is an admin
  const isAdmin = !!user;
  
  const signOut = async () => {
    await supabase.auth.signOut();
  };

  const value = {
    session,
    user,
    signOut,
    isAdmin
  };

  return <UserContext.Provider value={value}>{children}</UserContext.Provider>;
}

export function useUser() {
  const context = useContext(UserContext);
  if (context === undefined) {
    throw new Error('useUser must be used within a UserProvider');
  }
  return context;
}