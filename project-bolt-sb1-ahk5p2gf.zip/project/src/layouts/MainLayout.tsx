import { useState, useEffect, Fragment } from 'react';
import { Outlet, Link, useLocation } from 'react-router-dom';
import { Menu, X, Phone, ChevronDown } from 'lucide-react';
import { useUser } from '../contexts/UserContext';
import Footer from '../components/Footer';

const MainLayout = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { user, signOut } = useUser();
  const location = useLocation();

  // Listen for scroll events
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Close mobile menu when location changes
  useEffect(() => {
    setMobileMenuOpen(false);
  }, [location]);

  return (
    <div className="min-h-screen flex flex-col">
      {/* Top contact bar */}
      <div className="bg-maroon text-white py-2 px-4 hidden md:block">
        <div className="container mx-auto flex justify-between items-center">
          <div className="flex items-center space-x-6 text-sm">
            <a href="mailto:info@newsonia.com" className="hover:text-gold transition">
              info@newsonia.com
            </a>
            <a href="tel:+911234567890" className="flex items-center hover:text-gold transition">
              <Phone size={14} className="mr-1" /> +91 123 456 7890
            </a>
          </div>
          <div className="flex space-x-4 text-sm">
            <a href="#" className="hover:text-gold transition">FAQ</a>
            {user ? (
              <button onClick={() => signOut()} className="hover:text-gold transition">Logout</button>
            ) : (
              <Link to="/login" className="hover:text-gold transition">Login</Link>
            )}
          </div>
        </div>
      </div>
      
      {/* Main navigation */}
      <header 
        className={`sticky top-0 z-50 transition-all duration-300 ${
          isScrolled 
            ? 'bg-white shadow-md py-2' 
            : 'bg-transparent py-4'
        }`}
      >
        <div className="container mx-auto px-4">
          <nav className="flex justify-between items-center">
            {/* Logo */}
            <Link to="/" className="flex items-center">
              <span className="text-maroon font-heading text-2xl font-bold">New Sonia</span>
              <span className="text-gold font-heading text-2xl font-semibold">Tent House</span>
            </Link>
            
            {/* Desktop Navigation */}
            <div className="hidden md:flex space-x-8 items-center">
              <NavLink to="/" isActive={location.pathname === '/'}>Home</NavLink>
              <NavLink to="/gallery" isActive={location.pathname === '/gallery'}>Gallery</NavLink>
              <NavLink to="/packages" isActive={location.pathname === '/packages'}>Packages</NavLink>
              <NavLink to="/questionnaire" isActive={location.pathname === '/questionnaire'}>Find Your Package</NavLink>
              <NavLink to="/contact" isActive={location.pathname === '/contact'}>Contact</NavLink>
              
              {user && (
                <div className="relative group">
                  <button className="flex items-center text-gray-800 hover:text-maroon transition font-medium">
                    My Account <ChevronDown size={16} className="ml-1 group-hover:rotate-180 transition-transform duration-200" />
                  </button>
                  <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg overflow-hidden z-20 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 origin-top-right scale-95 group-hover:scale-100">
                    <div className="py-1">
                      {user.email === 'admin@newsonia.com' && (
                        <Link to="/admin" className="block px-4 py-2 text-sm text-gray-700 hover:bg-maroon hover:text-white transition">
                          Admin Dashboard
                        </Link>
                      )}
                      <Link to="/profile" className="block px-4 py-2 text-sm text-gray-700 hover:bg-maroon hover:text-white transition">
                        Profile
                      </Link>
                      <button 
                        onClick={() => signOut()}
                        className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-maroon hover:text-white transition"
                      >
                        Logout
                      </button>
                    </div>
                  </div>
                </div>
              )}
              
              {!user && (
                <Link 
                  to="/login" 
                  className="btn-primary"
                >
                  Login
                </Link>
              )}
            </div>
            
            {/* Mobile menu button */}
            <button 
              className="md:hidden text-maroon"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </nav>
        </div>
        
        {/* Mobile navigation */}
        <div 
          className={`md:hidden bg-white absolute w-full left-0 shadow-lg transition-all duration-300 ease-in-out ${
            mobileMenuOpen ? 'max-h-96 py-4' : 'max-h-0 overflow-hidden'
          }`}
        >
          <div className="flex flex-col space-y-3 px-4">
            <MobileNavLink to="/" isActive={location.pathname === '/'}>Home</MobileNavLink>
            <MobileNavLink to="/gallery" isActive={location.pathname === '/gallery'}>Gallery</MobileNavLink>
            <MobileNavLink to="/packages" isActive={location.pathname === '/packages'}>Packages</MobileNavLink>
            <MobileNavLink to="/questionnaire" isActive={location.pathname === '/questionnaire'}>Find Your Package</MobileNavLink>
            <MobileNavLink to="/contact" isActive={location.pathname === '/contact'}>Contact</MobileNavLink>
            
            {user ? (
              <Fragment>
                {user.email === 'admin@newsonia.com' && (
                  <MobileNavLink to="/admin" isActive={location.pathname.startsWith('/admin')}>
                    Admin Dashboard
                  </MobileNavLink>
                )}
                <MobileNavLink to="/profile" isActive={location.pathname === '/profile'}>
                  Profile
                </MobileNavLink>
                <button 
                  onClick={() => signOut()}
                  className="py-2 px-4 text-left text-maroon font-medium hover:bg-maroon/5 rounded-md"
                >
                  Logout
                </button>
              </Fragment>
            ) : (
              <Link 
                to="/login" 
                className="btn-primary text-center"
              >
                Login
              </Link>
            )}
          </div>
        </div>
      </header>
      
      {/* Main content */}
      <main className="flex-grow">
        <Outlet />
      </main>
      
      {/* Footer */}
      <Footer />
    </div>
  );
};

interface NavLinkProps {
  to: string;
  isActive: boolean;
  children: React.ReactNode;
}

const NavLink = ({ to, isActive, children }: NavLinkProps) => (
  <Link 
    to={to} 
    className={`${
      isActive 
        ? 'text-maroon font-semibold' 
        : 'text-gray-800'
    } hover:text-maroon transition`}
  >
    {children}
  </Link>
);

const MobileNavLink = ({ to, isActive, children }: NavLinkProps) => (
  <Link 
    to={to} 
    className={`${
      isActive 
        ? 'text-maroon font-semibold' 
        : 'text-gray-800'
    } py-2 px-4 block hover:bg-maroon/5 rounded-md font-medium`}
  >
    {children}
  </Link>
);

export default MainLayout;