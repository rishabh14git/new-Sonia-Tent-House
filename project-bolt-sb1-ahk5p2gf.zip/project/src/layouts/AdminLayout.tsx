import { useState } from 'react';
import { Outlet, Link, useLocation, Navigate } from 'react-router-dom';
import { 
  Menu, 
  X, 
  LayoutDashboard, 
  Users, 
  Package, 
  LogOut,
  Settings
} from 'lucide-react';
import { useUser } from '../contexts/UserContext';

const AdminLayout = () => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const location = useLocation();
  const { user, signOut } = useUser();
  
  // Redirect if not admin
  if (!user) {
    return <Navigate to="/login" />;
  }

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Sidebar for desktop */}
      <aside className="fixed inset-y-0 left-0 bg-maroon text-white w-64 hidden md:flex flex-col z-50">
        <div className="flex items-center justify-center h-16 border-b border-maroon-600">
          <Link to="/" className="flex items-center px-4">
            <span className="text-white font-heading text-xl font-bold">New Sonia</span>
            <span className="text-gold font-heading text-xl font-semibold">Admin</span>
          </Link>
        </div>
        
        <nav className="flex-1 py-6 px-4 space-y-1">
          <SidebarLink 
            to="/admin" 
            icon={<LayoutDashboard size={20} />} 
            isActive={location.pathname === '/admin'} 
            exact={true}
          >
            Dashboard
          </SidebarLink>
          <SidebarLink 
            to="/admin/clients" 
            icon={<Users size={20} />} 
            isActive={location.pathname === '/admin/clients'}
          >
            Clients
          </SidebarLink>
          <SidebarLink 
            to="/admin/packages" 
            icon={<Package size={20} />} 
            isActive={location.pathname === '/admin/packages'}
          >
            Packages
          </SidebarLink>
          <SidebarLink 
            to="/admin/settings" 
            icon={<Settings size={20} />} 
            isActive={location.pathname === '/admin/settings'}
          >
            Settings
          </SidebarLink>
        </nav>
        
        <div className="p-4 border-t border-maroon-600">
          <button 
            onClick={() => signOut()}
            className="flex items-center text-white opacity-75 hover:opacity-100 transition w-full"
          >
            <LogOut size={20} className="mr-3" /> Sign Out
          </button>
        </div>
      </aside>
      
      {/* Mobile sidebar */}
      <div 
        className={`fixed inset-0 bg-black bg-opacity-50 z-40 md:hidden transition-opacity ${
          sidebarOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'
        }`}
        onClick={() => setSidebarOpen(false)}
      />
      
      <aside 
        className={`fixed inset-y-0 left-0 bg-maroon text-white w-64 md:hidden z-50 transform transition-transform ${
          sidebarOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="flex items-center justify-between h-16 border-b border-maroon-600 px-4">
          <Link to="/" className="flex items-center">
            <span className="text-white font-heading text-xl font-bold">New Sonia</span>
            <span className="text-gold font-heading text-xl font-semibold">Admin</span>
          </Link>
          <button onClick={() => setSidebarOpen(false)}>
            <X size={24} />
          </button>
        </div>
        
        <nav className="flex-1 py-6 px-4 space-y-1">
          <SidebarLink 
            to="/admin" 
            icon={<LayoutDashboard size={20} />} 
            isActive={location.pathname === '/admin'} 
            exact={true}
          >
            Dashboard
          </SidebarLink>
          <SidebarLink 
            to="/admin/clients" 
            icon={<Users size={20} />} 
            isActive={location.pathname === '/admin/clients'}
          >
            Clients
          </SidebarLink>
          <SidebarLink 
            to="/admin/packages" 
            icon={<Package size={20} />} 
            isActive={location.pathname === '/admin/packages'}
          >
            Packages
          </SidebarLink>
          <SidebarLink 
            to="/admin/settings" 
            icon={<Settings size={20} />} 
            isActive={location.pathname === '/admin/settings'}
          >
            Settings
          </SidebarLink>
        </nav>
        
        <div className="p-4 border-t border-maroon-600">
          <button 
            onClick={() => signOut()}
            className="flex items-center text-white opacity-75 hover:opacity-100 transition w-full"
          >
            <LogOut size={20} className="mr-3" /> Sign Out
          </button>
        </div>
      </aside>
      
      {/* Main content */}
      <div className="md:pl-64">
        {/* Top navigation */}
        <nav className="bg-white shadow-sm h-16 flex items-center z-30 relative">
          <div className="px-4 flex items-center justify-between w-full">
            <button 
              className="text-gray-500 md:hidden"
              onClick={() => setSidebarOpen(true)}
            >
              <Menu size={24} />
            </button>
            
            <div className="ml-auto flex items-center">
              <div className="relative">
                <div className="flex items-center">
                  <div className="mr-2 text-right">
                    <div className="text-sm font-medium text-gray-700">{user.email}</div>
                    <div className="text-xs text-gray-500">Administrator</div>
                  </div>
                  <div className="h-8 w-8 rounded-full bg-maroon flex items-center justify-center text-white font-medium">
                    {user.email?.charAt(0).toUpperCase()}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </nav>
        
        {/* Page content */}
        <main className="py-6 px-4 sm:px-6 md:px-8">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

interface SidebarLinkProps {
  to: string;
  icon: React.ReactNode;
  isActive: boolean;
  exact?: boolean;
  children: React.ReactNode;
}

const SidebarLink = ({ to, icon, isActive, children }: SidebarLinkProps) => (
  <Link 
    to={to} 
    className={`flex items-center px-3 py-2 text-sm font-medium rounded-md transition ${
      isActive 
        ? 'bg-maroon-700 text-white' 
        : 'text-white/70 hover:bg-maroon-700 hover:text-white'
    }`}
  >
    <span className="mr-3">{icon}</span>
    {children}
  </Link>
);

export default AdminLayout;