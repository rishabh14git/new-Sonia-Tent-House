import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  Calendar, 
  Users, 
  Tent, 
  Utensils, 
  Award, 
  Star,
  ArrowRight
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import TestimonialCard from '../components/TestimonialCard';

interface Package {
  id: string;
  name: string;
  description: string;
  price: number;
  features: string[];
  image_url: string | null;
  category: string;
}

interface GalleryItem {
  id: string;
  image_url: string;
  title: string;
  category: string;
}

const Home = () => {
  const [popularPackages, setPopularPackages] = useState<Package[]>([]);
  const [galleryItems, setGalleryItems] = useState<GalleryItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true);
      
      try {
        // Fetch popular packages
        const { data: packagesData, error: packagesError } = await supabase
          .from('packages')
          .select('*')
          .eq('is_popular', true)
          .limit(3);
          
        if (packagesError) throw packagesError;
        
        // Fetch gallery items
        const { data: galleryData, error: galleryError } = await supabase
          .from('gallery')
          .select('id, image_url, title, category')
          .limit(6);
          
        if (galleryError) throw galleryError;
        
        setPopularPackages(packagesData || []);
        setGalleryItems(galleryData || []);
      } catch (error) {
        console.error('Error fetching data:', error);
        
        // Fallback data if database is not connected
        setPopularPackages([
          {
            id: '1',
            name: 'Wedding Bliss',
            description: 'Complete wedding tent and catering package for up to 150 guests',
            price: 80000,
            features: ['Elegant tent setup', 'Full catering', 'Decoration', 'Seating arrangement'],
            image_url: 'https://images.pexels.com/photos/1616113/pexels-photo-1616113.jpeg',
            category: 'wedding'
          },
          {
            id: '2',
            name: 'Corporate Event',
            description: 'Professional tent setup for corporate gatherings and meetings',
            price: 50000,
            features: ['Professional setup', 'Catering options', 'Technical equipment', 'Seating arrangement'],
            image_url: 'https://images.pexels.com/photos/2774556/pexels-photo-2774556.jpeg',
            category: 'corporate'
          },
          {
            id: '3',
            name: 'Birthday Celebration',
            description: 'Fun and festive setup for birthday parties of any age',
            price: 30000,
            features: ['Themed decoration', 'Catering options', 'Entertainment setup', 'Seating arrangement'],
            image_url: 'https://images.pexels.com/photos/2306281/pexels-photo-2306281.jpeg',
            category: 'birthday'
          }
        ]);
        
        setGalleryItems([
          {
            id: '1',
            image_url: 'https://images.pexels.com/photos/1779414/pexels-photo-1779414.jpeg',
            title: 'Elegant Wedding Setup',
            category: 'wedding'
          },
          {
            id: '2',
            image_url: 'https://images.pexels.com/photos/2291367/pexels-photo-2291367.jpeg',
            title: 'Corporate Meeting Arrangement',
            category: 'corporate'
          },
          {
            id: '3',
            image_url: 'https://images.pexels.com/photos/4201748/pexels-photo-4201748.jpeg',
            title: 'Birthday Party Decoration',
            category: 'birthday'
          },
          {
            id: '4',
            image_url: 'https://images.pexels.com/photos/7180795/pexels-photo-7180795.jpeg',
            title: 'Luxury Wedding Catering',
            category: 'wedding'
          },
          {
            id: '5',
            image_url: 'https://images.pexels.com/photos/1481117/pexels-photo-1481117.jpeg',
            title: 'Engagement Ceremony',
            category: 'engagement'
          },
          {
            id: '6',
            image_url: 'https://images.pexels.com/photos/6936034/pexels-photo-6936034.jpeg',
            title: 'Cultural Event Setup',
            category: 'cultural'
          }
        ]);
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchData();
  }, []);

  const testimonials = [
    {
      id: 1,
      name: 'Priya Sharma',
      role: 'Bride',
      testimonial: 'New Sonia Tent House made our wedding day absolutely perfect. The decoration was stunning and the service was exceptional.',
      image: 'https://images.pexels.com/photos/1181686/pexels-photo-1181686.jpeg',
      rating: 5
    },
    {
      id: 2,
      name: 'Rahul Verma',
      role: 'Event Manager',
      testimonial: 'I\'ve worked with many tent providers, but New Sonia stands out with their professionalism and quality of service. Highly recommended!',
      image: 'https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg',
      rating: 5
    },
    {
      id: 3,
      name: 'Ananya Gupta',
      role: 'Birthday Celebrant',
      testimonial: 'The birthday party setup was amazing! Everyone complimented the beautiful decorations and the food was delicious.',
      image: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg',
      rating: 4
    }
  ];

  return (
    <div>
      {/* Hero Section */}
      <section className="relative bg-hero-pattern bg-cover bg-center h-[80vh] text-white flex items-center">
        <div className="absolute inset-0 bg-black/40"></div>
        <div className="container mx-auto px-4 z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="max-w-3xl"
          >
            <h1 className="text-4xl md:text-6xl font-bold font-heading mb-4">
              Creating Magical Moments for Your Special Occasions
            </h1>
            <p className="text-xl md:text-2xl mb-8">
              Premier tent and catering services in New Delhi for weddings, parties, corporate events, and more.
            </p>
            <div className="flex flex-wrap gap-4">
              <Link to="/questionnaire" className="btn-secondary">
                Find Your Package
              </Link>
              <Link to="/contact" className="btn-outline border-white text-white hover:bg-white/20">
                Contact Us
              </Link>
            </div>
          </motion.div>
        </div>
      </section>
      
      {/* Services Section */}
      <section className="py-16 bg-cream">
        <div className="container mx-auto px-4">
          <h2 className="section-title text-center">Our Services</h2>
          <p className="section-subtitle text-center">
            From elegant weddings to corporate events, we provide complete solutions
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mt-12">
            <ServiceCard 
              icon={<Tent size={40} />}
              title="Tent Services"
              description="We provide elegant and customizable tent setups for various occasions and events."
            />
            <ServiceCard 
              icon={<Utensils size={40} />}
              title="Catering Services"
              description="Delicious food options ranging from traditional Indian cuisine to international flavors."
            />
            <ServiceCard 
              icon={<Users size={40} />}
              title="Event Planning"
              description="Complete event planning and management services to ensure your occasion is perfect."
            />
            <ServiceCard 
              icon={<Calendar size={40} />}
              title="Wedding Packages"
              description="Comprehensive wedding packages including decoration, catering, and tent setup."
            />
            <ServiceCard 
              icon={<Award size={40} />}
              title="Corporate Events"
              description="Professional setups for conferences, product launches, and corporate gatherings."
            />
            <ServiceCard 
              icon={<Star size={40} />}
              title="Decoration"
              description="Beautiful and elegant decoration services to enhance the ambiance of your event."
            />
          </div>
        </div>
      </section>
      
      {/* About Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center gap-10">
            <motion.div 
              className="md:w-1/2"
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <img 
                src="https://images.pexels.com/photos/2306281/pexels-photo-2306281.jpeg" 
                alt="About New Sonia Tent House" 
                className="rounded-lg shadow-xl w-full h-auto object-cover"
              />
            </motion.div>
            
            <motion.div 
              className="md:w-1/2"
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <h2 className="section-title">About New Sonia Tent House</h2>
              <p className="text-gray-600 mb-4">
                Established in 1990, New Sonia Tent House has been serving the Delhi region with premium tent and catering services for over three decades.
              </p>
              <p className="text-gray-600 mb-4">
                Founded by Mr. Mahinder Pal Katyal, we started as a small family business and have grown into one of the most trusted names in the industry.
              </p>
              <p className="text-gray-600 mb-6">
                Our commitment to quality, attention to detail, and customer satisfaction has allowed us to build long-lasting relationships with our clients and become their go-to choice for all events.
              </p>
              
              <div className="grid grid-cols-2 gap-6 mb-6">
                <div className="flex items-center">
                  <div className="bg-maroon/10 p-3 rounded-full mr-3">
                    <Calendar className="text-maroon" size={24} />
                  </div>
                  <div>
                    <h4 className="font-semibold">30+ Years</h4>
                    <p className="text-sm text-gray-500">Of Experience</p>
                  </div>
                </div>
                <div className="flex items-center">
                  <div className="bg-maroon/10 p-3 rounded-full mr-3">
                    <Star className="text-maroon" size={24} />
                  </div>
                  <div>
                    <h4 className="font-semibold">5000+</h4>
                    <p className="text-sm text-gray-500">Events Done</p>
                  </div>
                </div>
              </div>
              
              <Link to="/contact" className="btn-primary inline-flex items-center">
                Contact Us <ArrowRight size={16} className="ml-2" />
              </Link>
            </motion.div>
          </div>
        </div>
      </section>
      
      {/* Popular Packages Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="section-title text-center">Our Popular Packages</h2>
          <p className="section-subtitle text-center">
            Choose from our most sought-after packages designed for different occasions
          </p>
          
          {isLoading ? (
            <div className="flex justify-center my-12">
              <div className="w-10 h-10 border-4 border-t-maroon rounded-full animate-spin"></div>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mt-12">
              {popularPackages.map((pkg) => (
                <PackageCard key={pkg.id} package={pkg} />
              ))}
            </div>
          )}
          
          <div className="text-center mt-12">
            <Link to="/packages" className="btn-primary inline-flex items-center">
              View All Packages <ArrowRight size={16} className="ml-2" />
            </Link>
          </div>
        </div>
      </section>
      
      {/* Gallery Preview Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="section-title text-center">Our Gallery</h2>
          <p className="section-subtitle text-center">
            Take a look at some of our previous work
          </p>
          
          {isLoading ? (
            <div className="flex justify-center my-12">
              <div className="w-10 h-10 border-4 border-t-maroon rounded-full animate-spin"></div>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-12">
              {galleryItems.map((item) => (
                <GalleryPreviewItem key={item.id} item={item} />
              ))}
            </div>
          )}
          
          <div className="text-center mt-12">
            <Link to="/gallery" className="btn-primary inline-flex items-center">
              View Full Gallery <ArrowRight size={16} className="ml-2" />
            </Link>
          </div>
        </div>
      </section>
      
      {/* Testimonials Section */}
      <section className="py-16 bg-maroon/5">
        <div className="container mx-auto px-4">
          <h2 className="section-title text-center">What Our Clients Say</h2>
          <p className="section-subtitle text-center">
            Hear from our satisfied customers about their experience
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-12">
            {testimonials.map((testimonial) => (
              <TestimonialCard key={testimonial.id} testimonial={testimonial} />
            ))}
          </div>
        </div>
      </section>
      
      {/* Call to Action */}
      <section className="py-16 bg-maroon text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold font-heading mb-4">
            Ready to Create Your Perfect Event?
          </h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Get in touch with us to discuss your requirements and let us help you create a memorable event.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link to="/questionnaire" className="btn-secondary">
              Find Your Package
            </Link>
            <Link to="/contact" className="btn-outline border-white text-white hover:bg-white/20">
              Contact Us
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

interface ServiceCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
}

const ServiceCard = ({ icon, title, description }: ServiceCardProps) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    whileInView={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.5 }}
    viewport={{ once: true }}
    className="bg-white p-6 rounded-lg shadow-md hover:shadow-xl transition-shadow"
  >
    <div className="text-maroon mb-4">{icon}</div>
    <h3 className="text-xl font-semibold mb-2">{title}</h3>
    <p className="text-gray-600">{description}</p>
  </motion.div>
);

interface PackageCardProps {
  package: Package;
}

const PackageCard = ({ package: pkg }: PackageCardProps) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    whileInView={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.5 }}
    viewport={{ once: true }}
    className="bg-white rounded-lg overflow-hidden shadow-md hover:shadow-xl transition-shadow"
  >
    <div className="h-48 overflow-hidden">
      <img 
        src={pkg.image_url || 'https://images.pexels.com/photos/2306281/pexels-photo-2306281.jpeg'} 
        alt={pkg.name} 
        className="w-full h-full object-cover object-center transition-transform duration-300 hover:scale-105"
      />
    </div>
    <div className="p-6">
      <div className="flex justify-between items-start mb-2">
        <h3 className="text-xl font-semibold">{pkg.name}</h3>
        <span className="bg-gold text-maroon text-sm font-medium py-1 px-2 rounded">
          ₹{pkg.price.toLocaleString()}
        </span>
      </div>
      <p className="text-gray-600 mb-4">{pkg.description}</p>
      <ul className="space-y-2 mb-6">
        {pkg.features.slice(0, 3).map((feature, index) => (
          <li key={index} className="flex items-center">
            <span className="mr-2 text-green-500">✓</span>
            <span className="text-sm text-gray-600">{feature}</span>
          </li>
        ))}
      </ul>
      <Link 
        to={`/packages#${pkg.id}`} 
        className="block text-center py-2 bg-gray-100 text-maroon font-medium rounded-md hover:bg-maroon hover:text-white transition"
      >
        View Details
      </Link>
    </div>
  </motion.div>
);

interface GalleryPreviewItemProps {
  item: GalleryItem;
}

const GalleryPreviewItem = ({ item }: GalleryPreviewItemProps) => (
  <motion.div
    initial={{ opacity: 0, scale: 0.9 }}
    whileInView={{ opacity: 1, scale: 1 }}
    transition={{ duration: 0.5 }}
    viewport={{ once: true }}
    className="gallery-item rounded-lg overflow-hidden shadow-md"
  >
    <img 
      src={item.image_url} 
      alt={item.title} 
      className="w-full h-64 object-cover"
    />
    <div className="gallery-overlay flex flex-col justify-center items-center text-center p-4">
      <h3 className="text-xl font-semibold text-white mb-2">{item.title}</h3>
      <span className="text-white/80 text-sm bg-maroon/80 px-3 py-1 rounded-full">
        {item.category.charAt(0).toUpperCase() + item.category.slice(1)}
      </span>
    </div>
  </motion.div>
);

export default Home;