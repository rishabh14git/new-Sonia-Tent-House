import { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';
import { 
  Search, 
  Plus, 
  Edit, 
  Trash, 
  ChevronDown, 
  Download 
} from 'lucide-react';

interface Client {
  id: string;
  full_name: string;
  email: string;
  phone: string;
  address: string | null;
  created_at: string;
  last_login: string | null;
}

const ClientsList = () => {
  const [clients, setClients] = useState<Client[]>([]);
  const [filteredClients, setFilteredClients] = useState<Client[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(true);
  const [selectedClients, setSelectedClients] = useState<string[]>([]);

  useEffect(() => {
    const fetchClients = async () => {
      setLoading(true);
      
      try {
        // Simulate API call
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // Mock data
        const mockClients = [
          {
            id: '1',
            full_name: 'Rahul Sharma',
            email: 'rahul.sharma@example.com',
            phone: '+91 9876543210',
            address: 'Block A, Connaught Place, New Delhi',
            created_at: '2023-08-15T10:30:00Z',
            last_login: '2023-09-10T14:45:00Z'
          },
          {
            id: '2',
            full_name: 'Priya Patel',
            email: 'priya.patel@example.com',
            phone: '+91 9876543211',
            address: 'Sector 22, Gurugram, Haryana',
            created_at: '2023-07-20T09:15:00Z',
            last_login: '2023-09-12T11:20:00Z'
          },
          {
            id: '3',
            full_name: 'Vikram Singh',
            email: 'vikram.singh@example.com',
            phone: '+91 9876543212',
            address: 'DLF Phase 3, Gurugram, Haryana',
            created_at: '2023-06-05T15:45:00Z',
            last_login: '2023-09-05T10:10:00Z'
          },
          {
            id: '4',
            full_name: 'Ananya Gupta',
            email: 'ananya.gupta@example.com',
            phone: '+91 9876543213',
            address: 'Greater Kailash, New Delhi',
            created_at: '2023-05-12T11:30:00Z',
            last_login: '2023-08-28T13:25:00Z'
          },
          {
            id: '5',
            full_name: 'Raj Malhotra',
            email: 'raj.malhotra@example.com',
            phone: '+91 9876543214',
            address: 'Vasant Kunj, New Delhi',
            created_at: '2023-09-02T16:20:00Z',
            last_login: '2023-09-14T09:30:00Z'
          },
          {
            id: '6',
            full_name: 'Neha Verma',
            email: 'neha.verma@example.com',
            phone: '+91 9876543215',
            address: 'Rohini, New Delhi',
            created_at: '2023-08-10T12:40:00Z',
            last_login: '2023-09-08T16:15:00Z'
          },
          {
            id: '7',
            full_name: 'Amit Kumar',
            email: 'amit.kumar@example.com',
            phone: '+91 9876543216',
            address: 'Noida Sector 62, Uttar Pradesh',
            created_at: '2023-07-05T09:50:00Z',
            last_login: '2023-09-01T10:45:00Z'
          },
          {
            id: '8',
            full_name: 'Sonia Kapoor',
            email: 'sonia.kapoor@example.com',
            phone: '+91 9876543217',
            address: 'Malviya Nagar, New Delhi',
            created_at: '2023-06-18T14:10:00Z',
            last_login: '2023-08-22T11:30:00Z'
          }
        ];
        
        setClients(mockClients);
        setFilteredClients(mockClients);
        
      } catch (error) {
        console.error('Error fetching clients:', error);
      } finally {
        setLoading(false);
      }
    };
    
    fetchClients();
  }, []);
  
  // Handle search
  useEffect(() => {
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      const filtered = clients.filter(client => 
        client.full_name.toLowerCase().includes(query) || 
        client.email.toLowerCase().includes(query) ||
        client.phone.includes(query)
      );
      setFilteredClients(filtered);
    } else {
      setFilteredClients(clients);
    }
  }, [searchQuery, clients]);
  
  // Toggle client selection
  const toggleClientSelection = (id: string) => {
    setSelectedClients(prev => {
      if (prev.includes(id)) {
        return prev.filter(clientId => clientId !== id);
      } else {
        return [...prev, id];
      }
    });
  };
  
  // Toggle select all
  const toggleSelectAll = () => {
    if (selectedClients.length === filteredClients.length) {
      setSelectedClients([]);
    } else {
      setSelectedClients(filteredClients.map(client => client.id));
    }
  };

  return (
    <div>
      <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-bold">Clients</h1>
          <p className="text-gray-600">Manage all your clients from here</p>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-2">
          <button className="btn-outline flex items-center">
            <Download size={16} className="mr-1" /> Export
          </button>
          <button className="btn-primary flex items-center">
            <Plus size={16} className="mr-1" /> Add Client
          </button>
        </div>
      </div>
      
      {/* Filters and search */}
      <div className="bg-white rounded-lg shadow-sm mb-6">
        <div className="p-4 flex flex-col md:flex-row justify-between gap-4">
          <div className="relative flex-grow">
            <Search size={18} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Search clients..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:border-maroon focus:ring-1 focus:ring-maroon outline-none transition"
            />
          </div>
          
          <div className="flex flex-col sm:flex-row gap-2">
            <div className="relative">
              <button className="px-4 py-2 border border-gray-300 rounded-md bg-white text-gray-700 flex items-center">
                Filter <ChevronDown size={16} className="ml-1" />
              </button>
            </div>
            
            <div className="relative">
              <button className="px-4 py-2 border border-gray-300 rounded-md bg-white text-gray-700 flex items-center">
                Sort <ChevronDown size={16} className="ml-1" />
              </button>
            </div>
          </div>
        </div>
      </div>
      
      {/* Clients Table */}
      <div className="bg-white rounded-lg shadow-sm overflow-hidden">
        {loading ? (
          <div className="flex justify-center items-center py-20">
            <div className="w-10 h-10 border-4 border-t-maroon rounded-full animate-spin"></div>
          </div>
        ) : filteredClients.length === 0 ? (
          <div className="text-center py-12">
            <h3 className="text-lg font-medium mb-2">No clients found</h3>
            <p className="text-gray-500 mb-4">Try adjusting your search or filter to find clients</p>
            <button
              onClick={() => setSearchQuery('')}
              className="text-maroon hover:text-maroon/80 transition font-medium"
            >
              View all clients
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-gray-50 text-left">
                  <th className="py-3 px-4">
                    <div className="flex items-center">
                      <input
                        type="checkbox"
                        checked={selectedClients.length === filteredClients.length}
                        onChange={toggleSelectAll}
                        className="h-4 w-4 text-maroon rounded border-gray-300 focus:ring-maroon"
                      />
                    </div>
                  </th>
                  <th className="py-3 px-4 text-gray-500 font-medium">Name</th>
                  <th className="py-3 px-4 text-gray-500 font-medium">Email</th>
                  <th className="py-3 px-4 text-gray-500 font-medium">Phone</th>
                  <th className="py-3 px-4 text-gray-500 font-medium">Joined</th>
                  <th className="py-3 px-4 text-gray-500 font-medium">Last Login</th>
                  <th className="py-3 px-4 text-gray-500 font-medium">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredClients.map((client) => (
                  <tr key={client.id} className="border-t border-gray-100 hover:bg-gray-50">
                    <td className="py-3 px-4">
                      <input
                        type="checkbox"
                        checked={selectedClients.includes(client.id)}
                        onChange={() => toggleClientSelection(client.id)}
                        className="h-4 w-4 text-maroon rounded border-gray-300 focus:ring-maroon"
                      />
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex items-center">
                        <div className="h-8 w-8 rounded-full bg-gray-200 flex items-center justify-center text-gray-700 font-medium mr-3">
                          {client.full_name.charAt(0)}
                        </div>
                        <div>
                          <div className="font-medium">{client.full_name}</div>
                          <div className="text-xs text-gray-500">{client.address || 'No address'}</div>
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-4 text-gray-600">{client.email}</td>
                    <td className="py-3 px-4 text-gray-600">{client.phone}</td>
                    <td className="py-3 px-4 text-gray-600">
                      {new Date(client.created_at).toLocaleDateString()}
                    </td>
                    <td className="py-3 px-4 text-gray-600">
                      {client.last_login 
                        ? new Date(client.last_login).toLocaleDateString() 
                        : 'Never'
                      }
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex items-center space-x-2">
                        <button className="p-1 rounded-full hover:bg-gray-200 transition">
                          <Edit size={16} className="text-gray-600" />
                        </button>
                        <button className="p-1 rounded-full hover:bg-gray-200 transition">
                          <Trash size={16} className="text-gray-600" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        
        {/* Pagination */}
        {filteredClients.length > 0 && (
          <div className="py-3 px-4 border-t border-gray-100 flex items-center justify-between">
            <div className="text-sm text-gray-500">
              Showing <span className="font-medium">{filteredClients.length}</span> of <span className="font-medium">{clients.length}</span> clients
            </div>
            <div className="flex space-x-1">
              <button className="px-3 py-1 border border-gray-300 rounded-md text-sm bg-white text-gray-700 hover:bg-gray-50 transition">
                Previous
              </button>
              <button className="px-3 py-1 bg-maroon text-white rounded-md text-sm hover:bg-maroon/90 transition">
                1
              </button>
              <button className="px-3 py-1 border border-gray-300 rounded-md text-sm bg-white text-gray-700 hover:bg-gray-50 transition">
                2
              </button>
              <button className="px-3 py-1 border border-gray-300 rounded-md text-sm bg-white text-gray-700 hover:bg-gray-50 transition">
                3
              </button>
              <button className="px-3 py-1 border border-gray-300 rounded-md text-sm bg-white text-gray-700 hover:bg-gray-50 transition">
                Next
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ClientsList;