import { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';
import { 
  Users, 
  Calendar, 
  DollarSign, 
  CheckCircle,
  PieChart,
  BarChart,
  TrendingUp
} from 'lucide-react';

interface DashboardStats {
  totalClients: number;
  newInquiries: number;
  upcomingEvents: number;
  revenueThisMonth: number;
}

interface RecentInquiry {
  id: string;
  created_at: string;
  client_name: string;
  event_type: string;
  event_date: string | null;
  status: string;
}

const Dashboard = () => {
  const [stats, setStats] = useState<DashboardStats>({
    totalClients: 0,
    newInquiries: 0,
    upcomingEvents: 0,
    revenueThisMonth: 0
  });
  
  const [recentInquiries, setRecentInquiries] = useState<RecentInquiry[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchDashboardData = async () => {
      setLoading(true);
      
      try {
        // In a real app, these would be actual database queries
        // For demonstration, we'll use mock data
        
        // Simulate API delay
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // Mock dashboard stats
        setStats({
          totalClients: 156,
          newInquiries: 12,
          upcomingEvents: 8,
          revenueThisMonth: 450000
        });
        
        // Mock recent inquiries
        setRecentInquiries([
          {
            id: '1',
            created_at: '2023-09-15T10:30:00Z',
            client_name: 'Rahul Sharma',
            event_type: 'Wedding',
            event_date: '2023-11-20',
            status: 'pending'
          },
          {
            id: '2',
            created_at: '2023-09-14T14:45:00Z',
            client_name: 'Priya Patel',
            event_type: 'Birthday Party',
            event_date: '2023-10-05',
            status: 'confirmed'
          },
          {
            id: '3',
            created_at: '2023-09-13T09:15:00Z',
            client_name: 'Vikram Singh',
            event_type: 'Corporate Event',
            event_date: '2023-10-15',
            status: 'pending'
          },
          {
            id: '4',
            created_at: '2023-09-12T16:20:00Z',
            client_name: 'Ananya Gupta',
            event_type: 'Engagement',
            event_date: '2023-11-10',
            status: 'confirmed'
          },
          {
            id: '5',
            created_at: '2023-09-11T11:05:00Z',
            client_name: 'Raj Malhotra',
            event_type: 'Wedding',
            event_date: '2023-12-05',
            status: 'pending'
          }
        ]);
        
      } catch (error) {
        console.error('Error fetching dashboard data:', error);
      } finally {
        setLoading(false);
      }
    };
    
    fetchDashboardData();
  }, []);

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold">Dashboard</h1>
        <p className="text-gray-600">Welcome to your New Sonia Tent House dashboard</p>
      </div>
      
      {loading ? (
        <div className="flex justify-center py-12">
          <div className="w-10 h-10 border-4 border-t-maroon rounded-full animate-spin"></div>
        </div>
      ) : (
        <>
          {/* Stats Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <StatCard
              title="Total Clients"
              value={stats.totalClients}
              icon={<Users size={24} className="text-blue-500" />}
              change="+12% from last month"
              positive={true}
            />
            <StatCard
              title="New Inquiries"
              value={stats.newInquiries}
              icon={<TrendingUp size={24} className="text-green-500" />}
              change="+5 from last week"
              positive={true}
            />
            <StatCard
              title="Upcoming Events"
              value={stats.upcomingEvents}
              icon={<Calendar size={24} className="text-purple-500" />}
              change="Next 30 days"
              positive={null}
            />
            <StatCard
              title="Revenue (This Month)"
              value={`₹${stats.revenueThisMonth.toLocaleString()}`}
              icon={<DollarSign size={24} className="text-orange-500" />}
              change="+18% from last month"
              positive={true}
            />
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
            {/* Recent Inquiries */}
            <div className="lg:col-span-2 bg-white rounded-lg shadow-md p-6">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-lg font-semibold">Recent Inquiries</h2>
                <button className="text-sm text-maroon hover:text-maroon/80 transition">
                  View All
                </button>
              </div>
              
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-gray-200">
                      <th className="py-3 px-2 text-left text-sm font-medium text-gray-500">Client</th>
                      <th className="py-3 px-2 text-left text-sm font-medium text-gray-500">Event</th>
                      <th className="py-3 px-2 text-left text-sm font-medium text-gray-500">Date</th>
                      <th className="py-3 px-2 text-left text-sm font-medium text-gray-500">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {recentInquiries.map((inquiry) => (
                      <tr key={inquiry.id} className="border-b border-gray-100 hover:bg-gray-50">
                        <td className="py-3 px-2">
                          <div className="flex items-center">
                            <div className="h-8 w-8 rounded-full bg-gray-200 flex items-center justify-center text-gray-700 font-medium mr-3">
                              {inquiry.client_name.charAt(0)}
                            </div>
                            <span className="font-medium">{inquiry.client_name}</span>
                          </div>
                        </td>
                        <td className="py-3 px-2 text-gray-600">{inquiry.event_type}</td>
                        <td className="py-3 px-2 text-gray-600">
                          {inquiry.event_date ? new Date(inquiry.event_date).toLocaleDateString() : 'Not set'}
                        </td>
                        <td className="py-3 px-2">
                          <span className={`px-2 py-1 rounded-full text-xs ${
                            inquiry.status === 'confirmed' 
                              ? 'bg-green-100 text-green-800' 
                              : 'bg-yellow-100 text-yellow-800'
                          }`}>
                            {inquiry.status.charAt(0).toUpperCase() + inquiry.status.slice(1)}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
            
            {/* Summary Stats */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-lg font-semibold mb-4">Event Distribution</h2>
              
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Weddings</span>
                  <span className="font-medium">42%</span>
                </div>
                <div className="w-full bg-gray-200 h-2 rounded-full">
                  <div className="bg-maroon h-full rounded-full" style={{ width: '42%' }}></div>
                </div>
                
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Corporate Events</span>
                  <span className="font-medium">28%</span>
                </div>
                <div className="w-full bg-gray-200 h-2 rounded-full">
                  <div className="bg-blue-500 h-full rounded-full" style={{ width: '28%' }}></div>
                </div>
                
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Birthday Parties</span>
                  <span className="font-medium">18%</span>
                </div>
                <div className="w-full bg-gray-200 h-2 rounded-full">
                  <div className="bg-green-500 h-full rounded-full" style={{ width: '18%' }}></div>
                </div>
                
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Other Events</span>
                  <span className="font-medium">12%</span>
                </div>
                <div className="w-full bg-gray-200 h-2 rounded-full">
                  <div className="bg-yellow-500 h-full rounded-full" style={{ width: '12%' }}></div>
                </div>
              </div>
              
              <div className="mt-6 pt-6 border-t border-gray-200">
                <h3 className="text-sm font-medium text-gray-500 mb-3">Most Popular Package</h3>
                <div className="bg-maroon/10 p-4 rounded-md">
                  <h4 className="font-semibold text-maroon">Premium Wedding Package</h4>
                  <p className="text-sm text-gray-600 mt-1">Booked 24 times in the last 3 months</p>
                </div>
              </div>
            </div>
          </div>
          
          {/* Monthly Revenue Chart */}
          <div className="bg-white rounded-lg shadow-md p-6 mb-6">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-semibold">Monthly Revenue (2023)</h2>
              <div className="flex space-x-2">
                <button className="px-3 py-1 text-xs bg-maroon text-white rounded-md">
                  Year
                </button>
                <button className="px-3 py-1 text-xs bg-gray-100 text-gray-700 rounded-md hover:bg-gray-200 transition">
                  Month
                </button>
                <button className="px-3 py-1 text-xs bg-gray-100 text-gray-700 rounded-md hover:bg-gray-200 transition">
                  Week
                </button>
              </div>
            </div>
            
            <div className="h-64 flex items-end space-x-6 mt-4">
              {Array.from({ length: 12 }).map((_, i) => {
                // Generate random heights for the chart bars
                const height = Math.floor(Math.random() * 80) + 20;
                const value = Math.floor(Math.random() * 200000) + 100000;
                
                return (
                  <div key={i} className="flex-1 flex flex-col items-center">
                    <div 
                      className="w-full bg-maroon rounded-t-sm hover:bg-maroon/80 transition cursor-pointer"
                      style={{ height: `${height}%` }}
                      title={`₹${value.toLocaleString()}`}
                    ></div>
                    <div className="text-xs text-gray-500 mt-2">
                      {['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][i]}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
          
          {/* Quick Actions */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-indigo-50 rounded-lg p-4 flex">
              <div className="bg-indigo-100 p-3 rounded-md mr-4">
                <Calendar className="text-indigo-600" size={24} />
              </div>
              <div>
                <h3 className="font-medium">Schedule Event</h3>
                <p className="text-sm text-gray-600 mb-2">Add a new event to the calendar</p>
                <button className="text-indigo-600 text-sm hover:underline">
                  Quick Add
                </button>
              </div>
            </div>
            <div className="bg-green-50 rounded-lg p-4 flex">
              <div className="bg-green-100 p-3 rounded-md mr-4">
                <Users className="text-green-600" size={24} />
              </div>
              <div>
                <h3 className="font-medium">New Client</h3>
                <p className="text-sm text-gray-600 mb-2">Register a new client manually</p>
                <button className="text-green-600 text-sm hover:underline">
                  Create Client
                </button>
              </div>
            </div>
            <div className="bg-orange-50 rounded-lg p-4 flex">
              <div className="bg-orange-100 p-3 rounded-md mr-4">
                <BarChart className="text-orange-600" size={24} />
              </div>
              <div>
                <h3 className="font-medium">Generate Report</h3>
                <p className="text-sm text-gray-600 mb-2">Create a custom business report</p>
                <button className="text-orange-600 text-sm hover:underline">
                  Create Report
                </button>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

interface StatCardProps {
  title: string;
  value: number | string;
  icon: React.ReactNode;
  change: string;
  positive: boolean | null;
}

const StatCard = ({ title, value, icon, change, positive }: StatCardProps) => (
  <div className="bg-white rounded-lg shadow-md p-6">
    <div className="flex justify-between items-start">
      <div>
        <h3 className="text-sm font-medium text-gray-500">{title}</h3>
        <p className="text-2xl font-bold mt-1">{value}</p>
      </div>
      <div className="p-2 rounded-md bg-gray-50">{icon}</div>
    </div>
    <div className="mt-2">
      {positive !== null ? (
        <span className={`text-xs ${positive ? 'text-green-600' : 'text-red-600'}`}>
          {change}
        </span>
      ) : (
        <span className="text-xs text-gray-500">{change}</span>
      )}
    </div>
  </div>
);

export default Dashboard;