import { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';
import { 
  Plus, 
  Edit, 
  Trash, 
  Star, 
  ChevronUp, 
  ChevronDown, 
  Search,
  Check
} from 'lucide-react';

interface Package {
  id: string;
  name: string;
  description: string;
  price: number;
  features: string[];
  image_url: string | null;
  category: string;
  is_popular: boolean;
}

const PackageManagement = () => {
  const [packages, setPackages] = useState<Package[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [editingPackage, setEditingPackage] = useState<Package | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  
  // Package form state
  const [packageForm, setPackageForm] = useState({
    name: '',
    description: '',
    price: 0,
    category: '',
    is_popular: false,
    features: [''],
    image_url: ''
  });

  useEffect(() => {
    const fetchPackages = async () => {
      setLoading(true);
      
      try {
        // Simulate API call
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // Mock data
        const mockPackages = [
          {
            id: '1',
            name: 'Basic Wedding Package',
            description: 'Perfect for intimate weddings with essential services',
            price: 50000,
            features: [
              'Basic tent setup for up to 100 guests',
              'Standard decoration',
              'Basic catering (vegetarian options)',
              'Seating arrangement',
              'Basic lighting'
            ],
            image_url: 'https://images.pexels.com/photos/1616113/pexels-photo-1616113.jpeg',
            category: 'wedding',
            is_popular: false
          },
          {
            id: '2',
            name: 'Premium Wedding Package',
            description: 'Elegant and comprehensive setup for your special day',
            price: 100000,
            features: [
              'Deluxe tent setup for up to 200 guests',
              'Elaborate decoration with floral arrangements',
              'Premium catering (veg and non-veg options)',
              'Customized seating arrangement',
              'Enhanced lighting and sound system',
              'Photography services',
              'Valet parking'
            ],
            image_url: 'https://images.pexels.com/photos/1114425/pexels-photo-1114425.jpeg',
            category: 'wedding',
            is_popular: true
          },
          {
            id: '3',
            name: 'Luxury Wedding Package',
            description: 'The ultimate wedding experience with premium amenities',
            price: 200000,
            features: [
              'Luxury tent setup for up to 500 guests',
              'Exquisite decoration with premium flowers',
              'Gourmet catering with international cuisine',
              'VIP seating arrangement',
              'Professional lighting and sound system',
              'Photography and videography',
              'Valet parking with security personnel',
              'Wedding coordination services',
              'Welcome drinks and cocktail hour'
            ],
            image_url: 'https://images.pexels.com/photos/4297112/pexels-photo-4297112.jpeg',
            category: 'wedding',
            is_popular: true
          },
          {
            id: '4',
            name: 'Corporate Meeting Package',
            description: 'Professional setup for business meetings and seminars',
            price: 30000,
            features: [
              'Tent setup for up to 50 participants',
              'Professional seating arrangement',
              'Basic catering with tea/coffee service',
              'Projector and screen',
              'Basic sound system',
              'Wi-Fi connection'
            ],
            image_url: 'https://images.pexels.com/photos/2774556/pexels-photo-2774556.jpeg',
            category: 'corporate',
            is_popular: false
          },
          {
            id: '5',
            name: 'Corporate Event Package',
            description: 'Comprehensive solution for corporate events and product launches',
            price: 80000,
            features: [
              'Deluxe tent setup for up to 150 participants',
              'Professional stage and seating',
              'Premium catering options',
              'Advanced AV equipment',
              'Enhanced lighting system',
              'Wi-Fi connection',
              'Branding opportunities',
              'Registration desk'
            ],
            image_url: 'https://images.pexels.com/photos/3321797/pexels-photo-3321797.jpeg',
            category: 'corporate',
            is_popular: false
          },
          {
            id: '6',
            name: 'Birthday Basic Package',
            description: 'Fun setup for birthday celebrations',
            price: 20000,
            features: [
              'Tent setup for up to 50 guests',
              'Basic decoration with balloons',
              'Basic catering options',
              'Seating arrangement',
              'Basic sound system'
            ],
            image_url: 'https://images.pexels.com/photos/2306281/pexels-photo-2306281.jpeg',
            category: 'birthday',
            is_popular: false
          },
          {
            id: '7',
            name: 'Birthday Deluxe Package',
            description: 'Premium birthday party experience with all amenities',
            price: 40000,
            features: [
              'Tent setup for up to 100 guests',
              'Themed decoration with balloons and props',
              'Premium catering with cake',
              'DJ and entertainment',
              'Photography services',
              'Games and activities',
              'Return gifts for guests'
            ],
            image_url: 'https://images.pexels.com/photos/7180795/pexels-photo-7180795.jpeg',
            category: 'birthday',
            is_popular: true
          }
        ];
        
        setPackages(mockPackages);
        
      } catch (error) {
        console.error('Error fetching packages:', error);
      } finally {
        setLoading(false);
      }
    };
    
    fetchPackages();
  }, []);
  
  // Filter packages based on search
  const filteredPackages = packages.filter(pkg => 
    pkg.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    pkg.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
    pkg.category.toLowerCase().includes(searchQuery.toLowerCase())
  );
  
  // Open modal for editing
  const handleEditPackage = (pkg: Package) => {
    setEditingPackage(pkg);
    setPackageForm({
      name: pkg.name,
      description: pkg.description,
      price: pkg.price,
      category: pkg.category,
      is_popular: pkg.is_popular,
      features: [...pkg.features],
      image_url: pkg.image_url || ''
    });
    setIsModalOpen(true);
  };
  
  // Open modal for new package
  const handleNewPackage = () => {
    setEditingPackage(null);
    setPackageForm({
      name: '',
      description: '',
      price: 0,
      category: 'wedding',
      is_popular: false,
      features: [''],
      image_url: ''
    });
    setIsModalOpen(true);
  };
  
  // Toggle popular status
  const togglePopular = (id: string) => {
    setPackages(packages.map(pkg => 
      pkg.id === id ? { ...pkg, is_popular: !pkg.is_popular } : pkg
    ));
  };
  
  // Update form fields
  const handleFormChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    
    if (type === 'checkbox') {
      const checkbox = e.target as HTMLInputElement;
      setPackageForm({ ...packageForm, [name]: checkbox.checked });
    } else if (name === 'price') {
      setPackageForm({ ...packageForm, [name]: parseFloat(value) || 0 });
    } else {
      setPackageForm({ ...packageForm, [name]: value });
    }
  };
  
  // Add new feature field
  const addFeatureField = () => {
    setPackageForm({
      ...packageForm,
      features: [...packageForm.features, '']
    });
  };
  
  // Update feature at index
  const updateFeature = (index: number, value: string) => {
    const updatedFeatures = [...packageForm.features];
    updatedFeatures[index] = value;
    setPackageForm({
      ...packageForm,
      features: updatedFeatures
    });
  };
  
  // Remove feature at index
  const removeFeature = (index: number) => {
    const updatedFeatures = [...packageForm.features];
    updatedFeatures.splice(index, 1);
    setPackageForm({
      ...packageForm,
      features: updatedFeatures.length ? updatedFeatures : ['']
    });
  };
  
  // Submit form
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Filter out empty features
    const filteredFeatures = packageForm.features.filter(feature => feature.trim() !== '');
    
    if (editingPackage) {
      // Update existing package
      setPackages(packages.map(pkg => 
        pkg.id === editingPackage.id 
          ? { 
              ...pkg, 
              name: packageForm.name,
              description: packageForm.description,
              price: packageForm.price,
              category: packageForm.category,
              is_popular: packageForm.is_popular,
              features: filteredFeatures,
              image_url: packageForm.image_url || null
            } 
          : pkg
      ));
    } else {
      // Add new package
      setPackages([
        ...packages,
        {
          id: (packages.length + 1).toString(),
          name: packageForm.name,
          description: packageForm.description,
          price: packageForm.price,
          category: packageForm.category,
          is_popular: packageForm.is_popular,
          features: filteredFeatures,
          image_url: packageForm.image_url || null
        }
      ]);
    }
    
    setIsModalOpen(false);
  };

  return (
    <div>
      <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-bold">Package Management</h1>
          <p className="text-gray-600">Manage all your service packages from here</p>
        </div>
        
        <button 
          onClick={handleNewPackage}
          className="btn-primary flex items-center"
        >
          <Plus size={16} className="mr-1" /> Add Package
        </button>
      </div>
      
      {/* Search */}
      <div className="bg-white rounded-lg shadow-sm mb-6 p-4">
        <div className="relative">
          <Search size={18} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            placeholder="Search packages..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:border-maroon focus:ring-1 focus:ring-maroon outline-none transition"
          />
        </div>
      </div>
      
      {/* Packages List */}
      {loading ? (
        <div className="flex justify-center items-center py-20 bg-white rounded-lg shadow-sm">
          <div className="w-10 h-10 border-4 border-t-maroon rounded-full animate-spin"></div>
        </div>
      ) : filteredPackages.length === 0 ? (
        <div className="text-center py-12 bg-white rounded-lg shadow-sm">
          <h3 className="text-lg font-medium mb-2">No packages found</h3>
          <p className="text-gray-500 mb-4">Try adjusting your search or add a new package</p>
          <button
            onClick={handleNewPackage}
            className="btn-primary"
          >
            Add New Package
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-6">
          {filteredPackages.map((pkg) => (
            <div 
              key={pkg.id} 
              className="bg-white rounded-lg shadow-sm overflow-hidden border border-gray-100 hover:shadow-md transition-shadow"
            >
              <div className="flex flex-col md:flex-row">
                <div className="md:w-1/4 h-48 md:h-auto relative">
                  <img 
                    src={pkg.image_url || 'https://images.pexels.com/photos/2306281/pexels-photo-2306281.jpeg'} 
                    alt={pkg.name} 
                    className="w-full h-full object-cover"
                  />
                  {pkg.is_popular && (
                    <div className="absolute top-2 left-2 bg-gold text-maroon py-1 px-3 rounded-full text-xs font-medium flex items-center">
                      <Star size={14} className="mr-1 fill-maroon" /> Popular
                    </div>
                  )}
                </div>
                
                <div className="p-6 md:w-3/4">
                  <div className="flex justify-between items-start">
                    <div>
                      <h2 className="text-xl font-semibold">{pkg.name}</h2>
                      <div className="flex items-center mt-1 mb-3">
                        <span className="inline-block px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded-full mr-2">
                          {pkg.category.charAt(0).toUpperCase() + pkg.category.slice(1)}
                        </span>
                        <span className="text-xl font-bold text-maroon">
                          ₹{pkg.price.toLocaleString()}
                        </span>
                      </div>
                    </div>
                    
                    <div className="flex space-x-2">
                      <button 
                        onClick={() => togglePopular(pkg.id)}
                        className={`p-2 rounded-full ${
                          pkg.is_popular 
                            ? 'bg-gold/10 text-gold hover:bg-gold/20' 
                            : 'bg-gray-100 text-gray-500 hover:bg-gray-200'
                        } transition`}
                        title={pkg.is_popular ? "Remove from popular" : "Mark as popular"}
                      >
                        <Star size={18} className={pkg.is_popular ? "fill-gold" : ""} />
                      </button>
                      <button 
                        onClick={() => handleEditPackage(pkg)}
                        className="p-2 rounded-full bg-gray-100 text-gray-500 hover:bg-gray-200 transition"
                        title="Edit package"
                      >
                        <Edit size={18} />
                      </button>
                      <button 
                        className="p-2 rounded-full bg-gray-100 text-gray-500 hover:bg-gray-200 transition"
                        title="Delete package"
                      >
                        <Trash size={18} />
                      </button>
                    </div>
                  </div>
                  
                  <p className="text-gray-600 mb-4">{pkg.description}</p>
                  
                  <h3 className="font-medium mb-2">Features:</h3>
                  <ul className="grid grid-cols-1 md:grid-cols-2 gap-x-4 gap-y-2">
                    {pkg.features.map((feature, index) => (
                      <li key={index} className="flex items-start">
                        <Check size={16} className="text-green-500 mt-1 mr-2 flex-shrink-0" />
                        <span className="text-gray-700 text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
      
      {/* Package form modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-semibold">
                  {editingPackage ? 'Edit Package' : 'Add New Package'}
                </h2>
                <button 
                  onClick={() => setIsModalOpen(false)}
                  className="text-gray-500 hover:text-gray-700"
                >
                  &times;
                </button>
              </div>
              
              <form onSubmit={handleSubmit}>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                  <div>
                    <label htmlFor="name" className="block text-gray-700 text-sm font-medium mb-2">
                      Package Name <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      value={packageForm.name}
                      onChange={handleFormChange}
                      className="input-field"
                      required
                    />
                  </div>
                  <div>
                    <label htmlFor="category" className="block text-gray-700 text-sm font-medium mb-2">
                      Category <span className="text-red-500">*</span>
                    </label>
                    <select
                      id="category"
                      name="category"
                      value={packageForm.category}
                      onChange={handleFormChange}
                      className="input-field"
                      required
                    >
                      <option value="wedding">Wedding</option>
                      <option value="corporate">Corporate</option>
                      <option value="birthday">Birthday</option>
                      <option value="engagement">Engagement</option>
                      <option value="cultural">Cultural</option>
                      <option value="other">Other</option>
                    </select>
                  </div>
                </div>
                
                <div className="mb-4">
                  <label htmlFor="description" className="block text-gray-700 text-sm font-medium mb-2">
                    Description <span className="text-red-500">*</span>
                  </label>
                  <textarea
                    id="description"
                    name="description"
                    rows={3}
                    value={packageForm.description}
                    onChange={handleFormChange}
                    className="input-field"
                    required
                  />
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                  <div>
                    <label htmlFor="price" className="block text-gray-700 text-sm font-medium mb-2">
                      Price (₹) <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="number"
                      id="price"
                      name="price"
                      value={packageForm.price}
                      onChange={handleFormChange}
                      min="0"
                      step="1000"
                      className="input-field"
                      required
                    />
                  </div>
                  <div>
                    <label htmlFor="image_url" className="block text-gray-700 text-sm font-medium mb-2">
                      Image URL
                    </label>
                    <input
                      type="url"
                      id="image_url"
                      name="image_url"
                      value={packageForm.image_url}
                      onChange={handleFormChange}
                      placeholder="https://example.com/image.jpg"
                      className="input-field"
                    />
                  </div>
                </div>
                
                <div className="mb-4">
                  <div className="flex items-center mb-2">
                    <input
                      type="checkbox"
                      id="is_popular"
                      name="is_popular"
                      checked={packageForm.is_popular}
                      onChange={handleFormChange}
                      className="h-4 w-4 text-maroon rounded border-gray-300 focus:ring-maroon"
                    />
                    <label htmlFor="is_popular" className="ml-2 block text-gray-700 text-sm font-medium">
                      Mark as popular
                    </label>
                  </div>
                </div>
                
                <div className="mb-6">
                  <div className="flex justify-between items-center mb-2">
                    <label className="block text-gray-700 text-sm font-medium">
                      Features <span className="text-red-500">*</span>
                    </label>
                    <button
                      type="button"
                      onClick={addFeatureField}
                      className="text-sm text-maroon hover:text-maroon/80 transition font-medium"
                    >
                      + Add Feature
                    </button>
                  </div>
                  
                  {packageForm.features.map((feature, index) => (
                    <div key={index} className="flex items-center mb-2">
                      <input
                        type="text"
                        value={feature}
                        onChange={(e) => updateFeature(index, e.target.value)}
                        placeholder="Enter a feature"
                        className="input-field flex-grow mr-2"
                      />
                      <button
                        type="button"
                        onClick={() => removeFeature(index)}
                        className="p-2 rounded-md bg-gray-100 text-gray-500 hover:bg-gray-200 transition"
                        disabled={packageForm.features.length === 1}
                      >
                        &times;
                      </button>
                    </div>
                  ))}
                  {packageForm.features.length === 0 && (
                    <p className="text-red-500 text-sm">Add at least one feature</p>
                  )}
                </div>
                
                <div className="flex justify-end gap-2 pt-4 border-t border-gray-200">
                  <button
                    type="button"
                    onClick={() => setIsModalOpen(false)}
                    className="btn-outline"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="btn-primary"
                  >
                    {editingPackage ? 'Update Package' : 'Create Package'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default PackageManagement;