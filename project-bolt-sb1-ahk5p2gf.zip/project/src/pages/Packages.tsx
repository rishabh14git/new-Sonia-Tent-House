import { useState, useEffect, useRef } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import { supabase } from '../lib/supabase';
import { Check, Search } from 'lucide-react';

interface Package {
  id: string;
  name: string;
  description: string;
  price: number;
  features: string[];
  image_url: string | null;
  category: string;
  is_popular: boolean;
}

const Packages = () => {
  const [packages, setPackages] = useState<Package[]>([]);
  const [filteredPackages, setFilteredPackages] = useState<Package[]>([]);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(true);
  const location = useLocation();
  const packageRefs = useRef<{[key: string]: HTMLDivElement | null}>({});
  
  const categories = [
    { id: 'all', name: 'All Packages' },
    { id: 'wedding', name: 'Wedding' },
    { id: 'corporate', name: 'Corporate' },
    { id: 'birthday', name: 'Birthday' },
    { id: 'engagement', name: 'Engagement' },
    { id: 'other', name: 'Other' }
  ];

  useEffect(() => {
    const fetchPackages = async () => {
      setLoading(true);
      
      try {
        const { data, error } = await supabase
          .from('packages')
          .select('*')
          .order('price');
          
        if (error) throw error;
        
        setPackages(data || []);
        setFilteredPackages(data || []);
      } catch (error) {
        console.error('Error fetching packages:', error);
        
        // Fallback data
        const fallbackData = [
          {
            id: '1',
            name: 'Basic Wedding Package',
            description: 'Perfect for intimate weddings with essential services',
            price: 50000,
            features: [
              'Basic tent setup for up to 100 guests',
              'Standard decoration',
              'Basic catering (vegetarian options)',
              'Seating arrangement',
              'Basic lighting'
            ],
            image_url: 'https://images.pexels.com/photos/1616113/pexels-photo-1616113.jpeg',
            category: 'wedding',
            is_popular: false
          },
          {
            id: '2',
            name: 'Premium Wedding Package',
            description: 'Elegant and comprehensive setup for your special day',
            price: 100000,
            features: [
              'Deluxe tent setup for up to 200 guests',
              'Elaborate decoration with floral arrangements',
              'Premium catering (veg and non-veg options)',
              'Customized seating arrangement',
              'Enhanced lighting and sound system',
              'Photography services',
              'Valet parking'
            ],
            image_url: 'https://images.pexels.com/photos/1114425/pexels-photo-1114425.jpeg',
            category: 'wedding',
            is_popular: true
          },
          {
            id: '3',
            name: 'Luxury Wedding Package',
            description: 'The ultimate wedding experience with premium amenities',
            price: 200000,
            features: [
              'Luxury tent setup for up to 500 guests',
              'Exquisite decoration with premium flowers',
              'Gourmet catering with international cuisine',
              'VIP seating arrangement',
              'Professional lighting and sound system',
              'Photography and videography',
              'Valet parking with security personnel',
              'Wedding coordination services',
              'Welcome drinks and cocktail hour'
            ],
            image_url: 'https://images.pexels.com/photos/4297112/pexels-photo-4297112.jpeg',
            category: 'wedding',
            is_popular: true
          },
          {
            id: '4',
            name: 'Corporate Meeting Package',
            description: 'Professional setup for business meetings and seminars',
            price: 30000,
            features: [
              'Tent setup for up to 50 participants',
              'Professional seating arrangement',
              'Basic catering with tea/coffee service',
              'Projector and screen',
              'Basic sound system',
              'Wi-Fi connection'
            ],
            image_url: 'https://images.pexels.com/photos/2774556/pexels-photo-2774556.jpeg',
            category: 'corporate',
            is_popular: false
          },
          {
            id: '5',
            name: 'Corporate Event Package',
            description: 'Comprehensive solution for corporate events and product launches',
            price: 80000,
            features: [
              'Deluxe tent setup for up to 150 participants',
              'Professional stage and seating',
              'Premium catering options',
              'Advanced AV equipment',
              'Enhanced lighting system',
              'Wi-Fi connection',
              'Branding opportunities',
              'Registration desk'
            ],
            image_url: 'https://images.pexels.com/photos/3321797/pexels-photo-3321797.jpeg',
            category: 'corporate',
            is_popular: false
          },
          {
            id: '6',
            name: 'Birthday Basic Package',
            description: 'Fun setup for birthday celebrations',
            price: 20000,
            features: [
              'Tent setup for up to 50 guests',
              'Basic decoration with balloons',
              'Basic catering options',
              'Seating arrangement',
              'Basic sound system'
            ],
            image_url: 'https://images.pexels.com/photos/2306281/pexels-photo-2306281.jpeg',
            category: 'birthday',
            is_popular: false
          },
          {
            id: '7',
            name: 'Birthday Deluxe Package',
            description: 'Premium birthday party experience with all amenities',
            price: 40000,
            features: [
              'Tent setup for up to 100 guests',
              'Themed decoration with balloons and props',
              'Premium catering with cake',
              'DJ and entertainment',
              'Photography services',
              'Games and activities',
              'Return gifts for guests'
            ],
            image_url: 'https://images.pexels.com/photos/7180795/pexels-photo-7180795.jpeg',
            category: 'birthday',
            is_popular: true
          },
          {
            id: '8',
            name: 'Engagement Ceremony Package',
            description: 'Beautiful setup for engagement ceremonies',
            price: 60000,
            features: [
              'Elegant tent setup for up to 150 guests',
              'Floral decoration',
              'Catering services',
              'Seating arrangement',
              'Basic photography',
              'Sound system'
            ],
            image_url: 'https://images.pexels.com/photos/1481117/pexels-photo-1481117.jpeg',
            category: 'engagement',
            is_popular: false
          }
        ];
        
        setPackages(fallbackData);
        setFilteredPackages(fallbackData);
      } finally {
        setLoading(false);
      }
    };
    
    fetchPackages();
  }, []);
  
  // Handle category and search filtering
  useEffect(() => {
    let filtered = packages;
    
    // Apply category filter
    if (selectedCategory !== 'all') {
      filtered = filtered.filter(pkg => pkg.category === selectedCategory);
    }
    
    // Apply search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(pkg => 
        pkg.name.toLowerCase().includes(query) || 
        pkg.description.toLowerCase().includes(query) ||
        pkg.features.some(feature => feature.toLowerCase().includes(query))
      );
    }
    
    setFilteredPackages(filtered);
  }, [selectedCategory, searchQuery, packages]);
  
  // Scroll to specific package if ID is in URL hash
  useEffect(() => {
    const hash = location.hash.replace('#', '');
    if (hash && packageRefs.current[hash]) {
      setTimeout(() => {
        packageRefs.current[hash]?.scrollIntoView({ 
          behavior: 'smooth',
          block: 'center'
        });
      }, 500);
    }
  }, [location.hash, filteredPackages]);

  return (
    <div className="min-h-screen bg-cream py-16">
      <div className="container mx-auto px-4">
        <h1 className="section-title text-center">Our Packages</h1>
        <p className="section-subtitle text-center">
          Choose from our range of packages designed for different occasions and budgets
        </p>
        
        {/* Search and filter */}
        <div className="flex flex-col md:flex-row justify-between items-center gap-4 mb-8">
          <div className="flex flex-wrap justify-center gap-2 md:gap-4">
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => setSelectedCategory(category.id)}
                className={`px-4 py-2 rounded-full text-sm transition ${
                  selectedCategory === category.id
                    ? 'bg-maroon text-white'
                    : 'bg-white text-gray-700 hover:bg-gray-100'
                }`}
              >
                {category.name}
              </button>
            ))}
          </div>
          
          <div className="relative w-full md:w-64">
            <Search size={18} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Search packages..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-full focus:border-maroon focus:ring-1 focus:ring-maroon outline-none transition"
            />
          </div>
        </div>
        
        {/* Packages list */}
        {loading ? (
          <div className="flex justify-center items-center py-20">
            <div className="w-12 h-12 border-4 border-t-maroon rounded-full animate-spin"></div>
          </div>
        ) : filteredPackages.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-lg shadow-md">
            <h3 className="text-xl font-semibold mb-2">No packages found</h3>
            <p className="text-gray-600 mb-4">
              We couldn't find any packages matching your criteria.
            </p>
            <button 
              onClick={() => {
                setSelectedCategory('all');
                setSearchQuery('');
              }}
              className="btn-primary"
            >
              View All Packages
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-8">
            {filteredPackages.map((pkg) => (
              <motion.div
                key={pkg.id}
                ref={(el) => (packageRefs.current[pkg.id] = el)}
                id={pkg.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                viewport={{ once: true, margin: "-100px" }}
                className={`bg-white rounded-lg shadow-md overflow-hidden ${
                  location.hash === `#${pkg.id}` ? 'ring-2 ring-maroon ring-offset-2' : ''
                }`}
              >
                <div className="flex flex-col md:flex-row">
                  <div className="md:w-1/3 h-64 md:h-auto relative">
                    <img 
                      src={pkg.image_url || 'https://images.pexels.com/photos/2306281/pexels-photo-2306281.jpeg'} 
                      alt={pkg.name} 
                      className="w-full h-full object-cover"
                    />
                    {pkg.is_popular && (
                      <div className="absolute top-4 left-0 bg-gold text-maroon py-1 px-4 font-medium text-sm">
                        Popular Choice
                      </div>
                    )}
                  </div>
                  
                  <div className="md:w-2/3 p-6">
                    <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-4">
                      <h2 className="text-2xl font-semibold">{pkg.name}</h2>
                      <div className="flex items-center mt-2 md:mt-0">
                        <span className="bg-maroon text-white px-3 py-1 rounded-full text-sm mr-2">
                          {pkg.category.charAt(0).toUpperCase() + pkg.category.slice(1)}
                        </span>
                        <span className="text-2xl font-bold text-maroon">
                          ₹{pkg.price.toLocaleString()}
                        </span>
                      </div>
                    </div>
                    
                    <p className="text-gray-600 mb-4">{pkg.description}</p>
                    
                    <h3 className="font-semibold mb-2">Features:</h3>
                    <ul className="grid grid-cols-1 md:grid-cols-2 gap-x-4 gap-y-2 mb-6">
                      {pkg.features.map((feature, index) => (
                        <li key={index} className="flex items-start">
                          <Check size={18} className="text-green-500 mt-0.5 mr-2 flex-shrink-0" />
                          <span className="text-gray-700">{feature}</span>
                        </li>
                      ))}
                    </ul>
                    
                    <div className="flex flex-wrap gap-3">
                      <Link to="/contact" className="btn-primary">
                        Inquire Now
                      </Link>
                      <Link to="/questionnaire" className="btn-outline">
                        Find Your Package
                      </Link>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}
        
        {/* Call to action */}
        <div className="mt-16 bg-maroon text-white p-8 rounded-lg shadow-md text-center">
          <h2 className="text-2xl md:text-3xl font-bold mb-4">
            Need something more customized?
          </h2>
          <p className="text-lg mb-6 max-w-2xl mx-auto">
            We offer custom packages tailored to your specific requirements and budget. Contact us for a personalized quote.
          </p>
          <Link to="/contact" className="btn-secondary">
            Contact for Custom Quote
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Packages;