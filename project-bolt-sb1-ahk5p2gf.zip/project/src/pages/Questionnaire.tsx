import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { supabase } from '../lib/supabase';
import { useUser } from '../contexts/UserContext';
import { toast } from 'sonner';
import { 
  ArrowRight, 
  Calendar, 
  Users, 
  Sparkles, 
  DollarSign, 
  MessageSquare, 
  Check,
  Package
} from 'lucide-react';

interface QuestionnaireFormData {
  eventType: string;
  eventDate: string;
  guestCount: number;
  venueType: string;
  budgetRange: string;
  additionalServices: string[];
  specialRequests: string;
}

interface RecommendedPackage {
  id: string;
  name: string;
  description: string;
  price: number;
  features: string[];
  image_url: string | null;
}

const Questionnaire = () => {
  const { user } = useUser();
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState<QuestionnaireFormData>({
    eventType: '',
    eventDate: '',
    guestCount: 100,
    venueType: '',
    budgetRange: '',
    additionalServices: [],
    specialRequests: ''
  });
  const [loading, setLoading] = useState(false);
  const [recommendedPackages, setRecommendedPackages] = useState<RecommendedPackage[]>([]);
  const [contactSubmitted, setContactSubmitted] = useState(false);
  const [name, setName] = useState(user?.user_metadata?.full_name || '');
  const [email, setEmail] = useState(user?.email || '');
  const [phone, setPhone] = useState('');
  
  const totalSteps = 6;
  
  const handleNextStep = () => {
    const isStepValid = validateCurrentStep();
    if (isStepValid) {
      if (currentStep < totalSteps) {
        setCurrentStep(currentStep + 1);
      } else {
        handleSubmit();
      }
    }
  };
  
  const handlePrevStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };
  
  const validateCurrentStep = () => {
    switch (currentStep) {
      case 1:
        if (!formData.eventType) {
          toast.error('Please select an event type');
          return false;
        }
        return true;
      case 2:
        if (!formData.eventDate) {
          toast.error('Please select an event date');
          return false;
        }
        return true;
      case 3:
        return true; // Guest count has a default value
      case 4:
        if (!formData.venueType) {
          toast.error('Please select a venue type');
          return false;
        }
        return true;
      case 5:
        if (!formData.budgetRange) {
          toast.error('Please select a budget range');
          return false;
        }
        return true;
      default:
        return true;
    }
  };
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target as HTMLInputElement;
    
    if (type === 'checkbox') {
      const checkbox = e.target as HTMLInputElement;
      const isChecked = checkbox.checked;
      
      setFormData(prev => {
        const services = [...prev.additionalServices];
        
        if (isChecked) {
          services.push(value);
        } else {
          const index = services.indexOf(value);
          if (index > -1) {
            services.splice(index, 1);
          }
        }
        
        return { ...prev, additionalServices: services };
      });
    } else {
      setFormData(prev => ({ ...prev, [name]: value }));
    }
  };
  
  const handleSubmit = async () => {
    setLoading(true);
    
    try {
      // Simulate API call for package recommendations
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Generate recommendation based on form data
      const recommendations = generateRecommendations();
      setRecommendedPackages(recommendations);
      
      // If the user is logged in, save their preferences
      if (user) {
        await supabase
          .from('inquiries')
          .insert([{
            client_id: user.id,
            event_type: formData.eventType,
            guest_count: formData.guestCount,
            event_date: formData.eventDate,
            budget_range: formData.budgetRange,
            message: formData.specialRequests,
            status: 'new',
            recommended_package_id: recommendations[0]?.id || null
          }]);
      }
      
    } catch (error) {
      console.error('Error generating recommendations:', error);
      toast.error('There was an error processing your request. Please try again.');
    } finally {
      setLoading(false);
    }
  };
  
  const submitContactInfo = async () => {
    if (!name || !email || !phone) {
      toast.error('Please fill in all contact fields');
      return;
    }
    
    setLoading(true);
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      setContactSubmitted(true);
      toast.success('Thank you! Our team will contact you shortly.');
      
    } catch (error) {
      console.error('Error submitting contact info:', error);
      toast.error('There was an error submitting your contact info. Please try again.');
    } finally {
      setLoading(false);
    }
  };
  
  const generateRecommendations = (): RecommendedPackage[] => {
    // This is a simplified recommendation logic
    // In a real app, this would be more sophisticated and likely server-side
    
    const { eventType, guestCount, budgetRange } = formData;
    
    // Simple package recommendations based on event type, guest count, and budget
    let recommendedPackages: RecommendedPackage[] = [];
    
    // Primary package based on event type
    if (eventType === 'wedding') {
      if (guestCount <= 100 && budgetRange === 'low') {
        recommendedPackages.push({
          id: '1',
          name: 'Basic Wedding Package',
          description: 'Perfect for intimate weddings with essential services',
          price: 50000,
          features: [
            'Basic tent setup for up to 100 guests',
            'Standard decoration',
            'Basic catering (vegetarian options)',
            'Seating arrangement',
            'Basic lighting'
          ],
          image_url: 'https://images.pexels.com/photos/1616113/pexels-photo-1616113.jpeg'
        });
      } else if ((guestCount <= 200 && budgetRange === 'medium') || (guestCount <= 100 && budgetRange === 'high')) {
        recommendedPackages.push({
          id: '2',
          name: 'Premium Wedding Package',
          description: 'Elegant and comprehensive setup for your special day',
          price: 100000,
          features: [
            'Deluxe tent setup for up to 200 guests',
            'Elaborate decoration with floral arrangements',
            'Premium catering (veg and non-veg options)',
            'Customized seating arrangement',
            'Enhanced lighting and sound system',
            'Photography services',
            'Valet parking'
          ],
          image_url: 'https://images.pexels.com/photos/1114425/pexels-photo-1114425.jpeg'
        });
      } else {
        recommendedPackages.push({
          id: '3',
          name: 'Luxury Wedding Package',
          description: 'The ultimate wedding experience with premium amenities',
          price: 200000,
          features: [
            'Luxury tent setup for up to 500 guests',
            'Exquisite decoration with premium flowers',
            'Gourmet catering with international cuisine',
            'VIP seating arrangement',
            'Professional lighting and sound system',
            'Photography and videography',
            'Valet parking with security personnel',
            'Wedding coordination services',
            'Welcome drinks and cocktail hour'
          ],
          image_url: 'https://images.pexels.com/photos/4297112/pexels-photo-4297112.jpeg'
        });
      }
    } else if (eventType === 'corporate') {
      if (budgetRange === 'low') {
        recommendedPackages.push({
          id: '4',
          name: 'Corporate Meeting Package',
          description: 'Professional setup for business meetings and seminars',
          price: 30000,
          features: [
            'Tent setup for up to 50 participants',
            'Professional seating arrangement',
            'Basic catering with tea/coffee service',
            'Projector and screen',
            'Basic sound system',
            'Wi-Fi connection'
          ],
          image_url: 'https://images.pexels.com/photos/2774556/pexels-photo-2774556.jpeg'
        });
      } else {
        recommendedPackages.push({
          id: '5',
          name: 'Corporate Event Package',
          description: 'Comprehensive solution for corporate events and product launches',
          price: 80000,
          features: [
            'Deluxe tent setup for up to 150 participants',
            'Professional stage and seating',
            'Premium catering options',
            'Advanced AV equipment',
            'Enhanced lighting system',
            'Wi-Fi connection',
            'Branding opportunities',
            'Registration desk'
          ],
          image_url: 'https://images.pexels.com/photos/3321797/pexels-photo-3321797.jpeg'
        });
      }
    } else if (eventType === 'birthday') {
      if (budgetRange === 'low' || budgetRange === 'medium') {
        recommendedPackages.push({
          id: '6',
          name: 'Birthday Basic Package',
          description: 'Fun setup for birthday celebrations',
          price: 20000,
          features: [
            'Tent setup for up to 50 guests',
            'Basic decoration with balloons',
            'Basic catering options',
            'Seating arrangement',
            'Basic sound system'
          ],
          image_url: 'https://images.pexels.com/photos/2306281/pexels-photo-2306281.jpeg'
        });
      } else {
        recommendedPackages.push({
          id: '7',
          name: 'Birthday Deluxe Package',
          description: 'Premium birthday party experience with all amenities',
          price: 40000,
          features: [
            'Tent setup for up to 100 guests',
            'Themed decoration with balloons and props',
            'Premium catering with cake',
            'DJ and entertainment',
            'Photography services',
            'Games and activities',
            'Return gifts for guests'
          ],
          image_url: 'https://images.pexels.com/photos/7180795/pexels-photo-7180795.jpeg'
        });
      }
    } else {
      // Default fallback package
      recommendedPackages.push({
        id: '8',
        name: 'Custom Event Package',
        description: 'Tailored to your specific requirements',
        price: 60000,
        features: [
          'Customized tent setup',
          'Decoration according to theme',
          'Catering options as per requirement',
          'Seating arrangement',
          'Lighting and sound',
          'Additional services as needed'
        ],
        image_url: 'https://images.pexels.com/photos/587741/pexels-photo-587741.jpeg'
      });
    }
    
    // Add alternative packages
    if (recommendedPackages.length === 1) {
      // Add an upgrade option if the first recommendation isn't already the highest tier
      if (recommendedPackages[0].price < 100000) {
        recommendedPackages.push({
          id: '9',
          name: 'Upgrade Option',
          description: 'An enhanced version of our recommended package with premium features',
          price: recommendedPackages[0].price * 1.5,
          features: [
            ...recommendedPackages[0].features,
            'Premium decoration',
            'Enhanced catering menu',
            'Professional photography',
            'VIP treatment for hosts'
          ],
          image_url: 'https://images.pexels.com/photos/3321797/pexels-photo-3321797.jpeg'
        });
      }
      
      // Add an economy option if the first recommendation isn't already the lowest tier
      if (recommendedPackages[0].price > 30000) {
        recommendedPackages.push({
          id: '10',
          name: 'Economy Option',
          description: 'A more affordable alternative with essential services',
          price: recommendedPackages[0].price * 0.7,
          features: recommendedPackages[0].features.slice(0, 4),
          image_url: 'https://images.pexels.com/photos/587741/pexels-photo-587741.jpeg'
        });
      }
    }
    
    return recommendedPackages;
  };
  
  const renderStepContent = () => {
    switch (currentStep) {
      case 1:
        return (
          <div className="space-y-6">
            <div className="text-center mb-8">
              <h3 className="text-2xl font-semibold mb-2">What type of event are you planning?</h3>
              <p className="text-gray-600">This helps us recommend the best packages for your occasion</p>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              <EventTypeCard
                type="wedding"
                title="Wedding"
                description="Wedding ceremony, reception, or related events"
                selected={formData.eventType === 'wedding'}
                onSelect={() => setFormData({ ...formData, eventType: 'wedding' })}
              />
              <EventTypeCard
                type="corporate"
                title="Corporate Event"
                description="Meetings, conferences, or company gatherings"
                selected={formData.eventType === 'corporate'}
                onSelect={() => setFormData({ ...formData, eventType: 'corporate' })}
              />
              <EventTypeCard
                type="birthday"
                title="Birthday Party"
                description="Celebration for birthdays and anniversaries"
                selected={formData.eventType === 'birthday'}
                onSelect={() => setFormData({ ...formData, eventType: 'birthday' })}
              />
              <EventTypeCard
                type="engagement"
                title="Engagement Ceremony"
                description="Ring ceremonies and engagement parties"
                selected={formData.eventType === 'engagement'}
                onSelect={() => setFormData({ ...formData, eventType: 'engagement' })}
              />
              <EventTypeCard
                type="cultural"
                title="Cultural Event"
                description="Traditional and cultural gatherings"
                selected={formData.eventType === 'cultural'}
                onSelect={() => setFormData({ ...formData, eventType: 'cultural' })}
              />
              <EventTypeCard
                type="other"
                title="Other"
                description="Any other type of event or gathering"
                selected={formData.eventType === 'other'}
                onSelect={() => setFormData({ ...formData, eventType: 'other' })}
              />
            </div>
          </div>
        );
      case 2:
        return (
          <div className="space-y-6">
            <div className="text-center mb-8">
              <h3 className="text-2xl font-semibold mb-2">When is your event?</h3>
              <p className="text-gray-600">We need to check availability for your date</p>
            </div>
            
            <div className="max-w-md mx-auto">
              <div className="mb-6">
                <label htmlFor="eventDate" className="block text-gray-700 font-medium mb-2">
                  Event Date
                </label>
                <div className="relative">
                  <Calendar size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                  <input
                    type="date"
                    id="eventDate"
                    name="eventDate"
                    value={formData.eventDate}
                    onChange={handleChange}
                    min={new Date().toISOString().split('T')[0]}
                    className="input-field pl-10"
                    required
                  />
                </div>
                <p className="text-sm text-gray-500 mt-2">
                  Please select a date at least 7 days from today for proper planning
                </p>
              </div>
            </div>
          </div>
        );
      case 3:
        return (
          <div className="space-y-6">
            <div className="text-center mb-8">
              <h3 className="text-2xl font-semibold mb-2">How many guests are you expecting?</h3>
              <p className="text-gray-600">This helps us plan the space and arrangements</p>
            </div>
            
            <div className="max-w-md mx-auto">
              <div className="mb-6">
                <label htmlFor="guestCount" className="block text-gray-700 font-medium mb-2">
                  Number of Guests: <span className="text-maroon font-semibold">{formData.guestCount}</span>
                </label>
                <div className="relative">
                  <Users size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                  <input
                    type="range"
                    id="guestCount"
                    name="guestCount"
                    min="10"
                    max="500"
                    step="10"
                    value={formData.guestCount}
                    onChange={handleChange}
                    className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                  />
                </div>
                <div className="flex justify-between text-sm text-gray-500 mt-2">
                  <span>10</span>
                  <span>250</span>
                  <span>500</span>
                </div>
              </div>
            </div>
          </div>
        );
      case 4:
        return (
          <div className="space-y-6">
            <div className="text-center mb-8">
              <h3 className="text-2xl font-semibold mb-2">What type of venue are you looking for?</h3>
              <p className="text-gray-600">Select the venue type that best fits your event</p>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-w-2xl mx-auto">
              <VenueTypeCard
                type="indoor"
                title="Indoor Venue"
                description="AC tents with complete indoor setup"
                selected={formData.venueType === 'indoor'}
                onSelect={() => setFormData({ ...formData, venueType: 'indoor' })}
              />
              <VenueTypeCard
                type="outdoor"
                title="Outdoor Venue"
                description="Open-air setup with tent coverage"
                selected={formData.venueType === 'outdoor'}
                onSelect={() => setFormData({ ...formData, venueType: 'outdoor' })}
              />
              <VenueTypeCard
                type="mixed"
                title="Mixed Venue"
                description="Combination of indoor and outdoor spaces"
                selected={formData.venueType === 'mixed'}
                onSelect={() => setFormData({ ...formData, venueType: 'mixed' })}
              />
              <VenueTypeCard
                type="undecided"
                title="Not Sure Yet"
                description="Need advice on what would work best"
                selected={formData.venueType === 'undecided'}
                onSelect={() => setFormData({ ...formData, venueType: 'undecided' })}
              />
            </div>
          </div>
        );
      case 5:
        return (
          <div className="space-y-6">
            <div className="text-center mb-8">
              <h3 className="text-2xl font-semibold mb-2">What is your budget range?</h3>
              <p className="text-gray-600">This helps us recommend packages within your budget</p>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 max-w-2xl mx-auto">
              <BudgetCard
                range="low"
                title="Economy"
                amount="₹20,000 - ₹50,000"
                description="Basic setup with essential services"
                selected={formData.budgetRange === 'low'}
                onSelect={() => setFormData({ ...formData, budgetRange: 'low' })}
              />
              <BudgetCard
                range="medium"
                title="Standard"
                amount="₹50,000 - ₹1,00,000"
                description="Premium setup with enhanced services"
                selected={formData.budgetRange === 'medium'}
                onSelect={() => setFormData({ ...formData, budgetRange: 'medium' })}
              />
              <BudgetCard
                range="high"
                title="Luxury"
                amount="₹1,00,000+"
                description="Luxurious setup with comprehensive services"
                selected={formData.budgetRange === 'high'}
                onSelect={() => setFormData({ ...formData, budgetRange: 'high' })}
              />
            </div>
          </div>
        );
      case 6:
        return (
          <div className="space-y-6">
            <div className="text-center mb-8">
              <h3 className="text-2xl font-semibold mb-2">Any additional requirements?</h3>
              <p className="text-gray-600">Select any additional services you might need</p>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-w-2xl mx-auto mb-6">
              <div className="flex items-start p-4 bg-white rounded-lg border border-gray-200">
                <input
                  type="checkbox"
                  id="catering"
                  name="additionalServices"
                  value="catering"
                  checked={formData.additionalServices.includes('catering')}
                  onChange={handleChange}
                  className="h-5 w-5 text-maroon rounded border-gray-300 focus:ring-maroon mt-0.5"
                />
                <label htmlFor="catering" className="ml-3">
                  <span className="block text-gray-800 font-medium">Catering Services</span>
                  <span className="block text-gray-600 text-sm">Food and beverage services for your event</span>
                </label>
              </div>
              
              <div className="flex items-start p-4 bg-white rounded-lg border border-gray-200">
                <input
                  type="checkbox"
                  id="decoration"
                  name="additionalServices"
                  value="decoration"
                  checked={formData.additionalServices.includes('decoration')}
                  onChange={handleChange}
                  className="h-5 w-5 text-maroon rounded border-gray-300 focus:ring-maroon mt-0.5"
                />
                <label htmlFor="decoration" className="ml-3">
                  <span className="block text-gray-800 font-medium">Decoration</span>
                  <span className="block text-gray-600 text-sm">Custom decoration for your event theme</span>
                </label>
              </div>
              
              <div className="flex items-start p-4 bg-white rounded-lg border border-gray-200">
                <input
                  type="checkbox"
                  id="photography"
                  name="additionalServices"
                  value="photography"
                  checked={formData.additionalServices.includes('photography')}
                  onChange={handleChange}
                  className="h-5 w-5 text-maroon rounded border-gray-300 focus:ring-maroon mt-0.5"
                />
                <label htmlFor="photography" className="ml-3">
                  <span className="block text-gray-800 font-medium">Photography</span>
                  <span className="block text-gray-600 text-sm">Professional photo and video services</span>
                </label>
              </div>
              
              <div className="flex items-start p-4 bg-white rounded-lg border border-gray-200">
                <input
                  type="checkbox"
                  id="entertainment"
                  name="additionalServices"
                  value="entertainment"
                  checked={formData.additionalServices.includes('entertainment')}
                  onChange={handleChange}
                  className="h-5 w-5 text-maroon rounded border-gray-300 focus:ring-maroon mt-0.5"
                />
                <label htmlFor="entertainment" className="ml-3">
                  <span className="block text-gray-800 font-medium">Entertainment</span>
                  <span className="block text-gray-600 text-sm">Music, DJ, or live performances</span>
                </label>
              </div>
              
              <div className="flex items-start p-4 bg-white rounded-lg border border-gray-200">
                <input
                  type="checkbox"
                  id="transportation"
                  name="additionalServices"
                  value="transportation"
                  checked={formData.additionalServices.includes('transportation')}
                  onChange={handleChange}
                  className="h-5 w-5 text-maroon rounded border-gray-300 focus:ring-maroon mt-0.5"
                />
                <label htmlFor="transportation" className="ml-3">
                  <span className="block text-gray-800 font-medium">Transportation</span>
                  <span className="block text-gray-600 text-sm">Valet parking and transport services</span>
                </label>
              </div>
              
              <div className="flex items-start p-4 bg-white rounded-lg border border-gray-200">
                <input
                  type="checkbox"
                  id="coordination"
                  name="additionalServices"
                  value="coordination"
                  checked={formData.additionalServices.includes('coordination')}
                  onChange={handleChange}
                  className="h-5 w-5 text-maroon rounded border-gray-300 focus:ring-maroon mt-0.5"
                />
                <label htmlFor="coordination" className="ml-3">
                  <span className="block text-gray-800 font-medium">Event Coordination</span>
                  <span className="block text-gray-600 text-sm">Professional event planning and management</span>
                </label>
              </div>
            </div>
            
            <div className="max-w-2xl mx-auto">
              <label htmlFor="specialRequests" className="block text-gray-700 font-medium mb-2">
                Any special requests or requirements?
              </label>
              <textarea
                id="specialRequests"
                name="specialRequests"
                rows={4}
                placeholder="Tell us about any specific requirements or special requests for your event..."
                value={formData.specialRequests}
                onChange={handleChange}
                className="input-field"
              />
            </div>
          </div>
        );
      default:
        return null;
    }
  };
  
  const renderRecommendations = () => {
    return (
      <div className="py-6">
        <div className="text-center mb-8">
          <h2 className="section-title">Recommended Packages</h2>
          <p className="section-subtitle">
            Based on your preferences, we've selected these packages for you
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          {recommendedPackages.map((pkg, index) => (
            <motion.div
              key={pkg.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.2 }}
              className={`bg-white rounded-lg overflow-hidden shadow-md hover:shadow-xl transition-shadow relative ${
                index === 0 ? 'ring-2 ring-maroon' : ''
              }`}
            >
              {index === 0 && (
                <div className="absolute top-4 right-4 bg-maroon text-white py-1 px-3 rounded-full text-sm font-medium">
                  Best Match
                </div>
              )}
              
              <div className="h-48 overflow-hidden">
                <img 
                  src={pkg.image_url || 'https://images.pexels.com/photos/2306281/pexels-photo-2306281.jpeg'} 
                  alt={pkg.name} 
                  className="w-full h-full object-cover object-center transition-transform duration-300 hover:scale-105"
                />
              </div>
              
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-2">{pkg.name}</h3>
                <p className="text-gray-600 mb-4">{pkg.description}</p>
                <div className="mb-4">
                  <span className="text-2xl font-bold text-maroon">₹{pkg.price.toLocaleString()}</span>
                </div>
                
                <h4 className="font-medium mb-2">Features:</h4>
                <ul className="space-y-2 mb-6">
                  {pkg.features.slice(0, 4).map((feature, i) => (
                    <li key={i} className="flex items-start">
                      <Check size={18} className="text-green-500 mt-0.5 mr-2 flex-shrink-0" />
                      <span className="text-sm text-gray-600">{feature}</span>
                    </li>
                  ))}
                  {pkg.features.length > 4 && (
                    <li className="text-sm text-maroon">
                      +{pkg.features.length - 4} more features
                    </li>
                  )}
                </ul>
              </div>
            </motion.div>
          ))}
        </div>
        
        {!contactSubmitted ? (
          <div className="max-w-2xl mx-auto bg-white p-6 rounded-lg shadow-md">
            <h3 className="text-xl font-semibold mb-4">Enter your contact information</h3>
            <p className="text-gray-600 mb-6">
              Leave your details and our team will contact you to discuss the package details and answer any questions.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div>
                <label htmlFor="name" className="block text-gray-700 text-sm font-medium mb-2">
                  Full Name <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  id="name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="input-field"
                  required
                />
              </div>
              <div>
                <label htmlFor="email" className="block text-gray-700 text-sm font-medium mb-2">
                  Email Address <span className="text-red-500">*</span>
                </label>
                <input
                  type="email"
                  id="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="input-field"
                  required
                />
              </div>
            </div>
            
            <div className="mb-6">
              <label htmlFor="phone" className="block text-gray-700 text-sm font-medium mb-2">
                Phone Number <span className="text-red-500">*</span>
              </label>
              <input
                type="tel"
                id="phone"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="input-field"
                required
              />
            </div>
            
            <button
              onClick={submitContactInfo}
              className="btn-primary w-full flex items-center justify-center"
              disabled={loading}
            >
              {loading ? (
                <span className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></span>
              ) : null}
              Submit Request
            </button>
          </div>
        ) : (
          <div className="max-w-2xl mx-auto bg-green-50 border border-green-200 p-6 rounded-lg shadow-md text-center">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Check size={32} className="text-green-500" />
            </div>
            <h3 className="text-xl font-semibold mb-2">Thank You!</h3>
            <p className="text-gray-600 mb-4">
              Your request has been submitted successfully. Our team will contact you shortly to discuss the packages and answer any questions you might have.
            </p>
            <p className="text-gray-600">
              If you have any urgent queries, please call us at <a href="tel:+911234567890" className="text-maroon font-medium">+91 123 456 7890</a>
            </p>
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-cream py-16">
      <div className="container mx-auto px-4">
        {recommendedPackages.length === 0 ? (
          <>
            <h1 className="section-title text-center">Find Your Perfect Package</h1>
            <p className="section-subtitle text-center">
              Answer a few questions and we'll recommend the best packages for your event
            </p>
            
            {/* Progress bar */}
            <div className="max-w-3xl mx-auto mb-8">
              <div className="h-2 bg-gray-200 rounded-full">
                <div 
                  className="h-full bg-maroon rounded-full transition-all duration-300"
                  style={{ width: `${(currentStep / totalSteps) * 100}%` }}
                ></div>
              </div>
              <div className="flex justify-between text-sm text-gray-500 mt-2">
                <span>Start</span>
                <span>Halfway</span>
                <span>Complete</span>
              </div>
            </div>
            
            {/* Question content */}
            <div className="max-w-4xl mx-auto bg-white p-6 md:p-8 rounded-lg shadow-md">
              <AnimatePresence mode="wait">
                <motion.div
                  key={currentStep}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.3 }}
                >
                  {renderStepContent()}
                </motion.div>
              </AnimatePresence>
              
              {/* Navigation buttons */}
              <div className="flex justify-between mt-8 pt-6 border-t border-gray-200">
                <button
                  onClick={handlePrevStep}
                  className={`btn-outline ${currentStep === 1 ? 'invisible' : ''}`}
                >
                  Previous
                </button>
                <button
                  onClick={handleNextStep}
                  className="btn-primary flex items-center"
                  disabled={loading}
                >
                  {loading ? (
                    <span className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></span>
                  ) : null}
                  {currentStep === totalSteps ? 'Get Recommendations' : 'Next'}
                  {!loading && currentStep !== totalSteps && <ArrowRight size={16} className="ml-2" />}
                </button>
              </div>
            </div>
          </>
        ) : (
          renderRecommendations()
        )}
      </div>
    </div>
  );
};

interface EventTypeCardProps {
  type: string;
  title: string;
  description: string;
  selected: boolean;
  onSelect: () => void;
}

const EventTypeCard = ({ type, title, description, selected, onSelect }: EventTypeCardProps) => {
  let icon;
  switch (type) {
    case 'wedding':
      icon = <Sparkles size={32} />;
      break;
    case 'corporate':
      icon = <Users size={32} />;
      break;
    case 'birthday':
      icon = <Package size={32} />;
      break;
    default:
      icon = <Sparkles size={32} />;
  }

  return (
    <div
      className={`p-4 rounded-lg cursor-pointer transition-all border-2 ${
        selected 
          ? 'border-maroon bg-maroon/5' 
          : 'border-gray-200 bg-white hover:border-gray-300'
      }`}
      onClick={onSelect}
    >
      <div className="mb-3 text-maroon">{icon}</div>
      <h4 className="font-semibold text-lg mb-1">{title}</h4>
      <p className="text-gray-600 text-sm">{description}</p>
    </div>
  );
};

interface VenueTypeCardProps {
  type: string;
  title: string;
  description: string;
  selected: boolean;
  onSelect: () => void;
}

const VenueTypeCard = ({ type, title, description, selected, onSelect }: VenueTypeCardProps) => {
  return (
    <div
      className={`p-4 rounded-lg cursor-pointer transition-all border-2 ${
        selected 
          ? 'border-maroon bg-maroon/5' 
          : 'border-gray-200 bg-white hover:border-gray-300'
      }`}
      onClick={onSelect}
    >
      <h4 className="font-semibold text-lg mb-1">{title}</h4>
      <p className="text-gray-600 text-sm">{description}</p>
    </div>
  );
};

interface BudgetCardProps {
  range: string;
  title: string;
  amount: string;
  description: string;
  selected: boolean;
  onSelect: () => void;
}

const BudgetCard = ({ range, title, amount, description, selected, onSelect }: BudgetCardProps) => {
  return (
    <div
      className={`p-4 rounded-lg cursor-pointer transition-all border-2 ${
        selected 
          ? 'border-maroon bg-maroon/5' 
          : 'border-gray-200 bg-white hover:border-gray-300'
      }`}
      onClick={onSelect}
    >
      <div className="mb-2 text-maroon">
        <DollarSign size={24} />
      </div>
      <h4 className="font-semibold text-lg mb-1">{title}</h4>
      <p className="text-maroon font-medium mb-1">{amount}</p>
      <p className="text-gray-600 text-sm">{description}</p>
    </div>
  );
};

export default Questionnaire;