import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { supabase } from '../lib/supabase';

interface GalleryItem {
  id: string;
  title: string;
  description: string | null;
  image_url: string;
  category: string;
  tags: string[] | null;
  created_at: string;
}

const Gallery = () => {
  const [items, setItems] = useState<GalleryItem[]>([]);
  const [filteredItems, setFilteredItems] = useState<GalleryItem[]>([]);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [loading, setLoading] = useState(true);
  const [selectedItem, setSelectedItem] = useState<GalleryItem | null>(null);

  const categories = [
    { id: 'all', name: 'All' },
    { id: 'wedding', name: 'Wedding' },
    { id: 'corporate', name: 'Corporate' },
    { id: 'birthday', name: 'Birthday' },
    { id: 'engagement', name: 'Engagement' },
    { id: 'cultural', name: 'Cultural' },
  ];

  useEffect(() => {
    const fetchGallery = async () => {
      setLoading(true);
      
      try {
        const { data, error } = await supabase
          .from('gallery')
          .select('*')
          .order('created_at', { ascending: false });
          
        if (error) throw error;
        
        setItems(data || []);
        setFilteredItems(data || []);
      } catch (error) {
        console.error('Error fetching gallery:', error);
        
        // Fallback data
        const fallbackData = [
          {
            id: '1',
            title: 'Elegant Wedding Setup',
            description: 'Complete wedding tent decoration for a grand ceremony',
            image_url: 'https://images.pexels.com/photos/1779414/pexels-photo-1779414.jpeg',
            category: 'wedding',
            tags: ['wedding', 'decoration', 'tent'],
            created_at: '2023-08-15T10:00:00Z'
          },
          {
            id: '2',
            title: 'Corporate Meeting Arrangement',
            description: 'Professional setup for a corporate gathering',
            image_url: 'https://images.pexels.com/photos/2291367/pexels-photo-2291367.jpeg',
            category: 'corporate',
            tags: ['corporate', 'meeting', 'professional'],
            created_at: '2023-07-22T14:30:00Z'
          },
          {
            id: '3',
            title: 'Birthday Party Decoration',
            description: 'Colorful setup for a birthday celebration',
            image_url: 'https://images.pexels.com/photos/4201748/pexels-photo-4201748.jpeg',
            category: 'birthday',
            tags: ['birthday', 'party', 'decoration'],
            created_at: '2023-06-10T16:00:00Z'
          },
          {
            id: '4',
            title: 'Luxury Wedding Catering',
            description: 'Exquisite food presentation for a wedding reception',
            image_url: 'https://images.pexels.com/photos/7180795/pexels-photo-7180795.jpeg',
            category: 'wedding',
            tags: ['wedding', 'catering', 'food'],
            created_at: '2023-05-18T19:00:00Z'
          },
          {
            id: '5',
            title: 'Engagement Ceremony',
            description: 'Beautiful setup for an engagement event',
            image_url: 'https://images.pexels.com/photos/1481117/pexels-photo-1481117.jpeg',
            category: 'engagement',
            tags: ['engagement', 'ceremony', 'decoration'],
            created_at: '2023-04-05T15:30:00Z'
          },
          {
            id: '6',
            title: 'Cultural Event Setup',
            description: 'Traditional decoration for a cultural gathering',
            image_url: 'https://images.pexels.com/photos/6936034/pexels-photo-6936034.jpeg',
            category: 'cultural',
            tags: ['cultural', 'traditional', 'decoration'],
            created_at: '2023-03-12T12:00:00Z'
          },
          {
            id: '7',
            title: 'Wedding Reception Decoration',
            description: 'Elegant and sophisticated setup for a wedding reception',
            image_url: 'https://images.pexels.com/photos/1128782/pexels-photo-1128782.jpeg',
            category: 'wedding',
            tags: ['wedding', 'reception', 'elegant'],
            created_at: '2023-02-28T17:30:00Z'
          },
          {
            id: '8',
            title: 'Corporate Lunch Event',
            description: 'Catering and table setup for a corporate lunch',
            image_url: 'https://images.pexels.com/photos/2788792/pexels-photo-2788792.jpeg',
            category: 'corporate',
            tags: ['corporate', 'lunch', 'catering'],
            created_at: '2023-01-20T13:00:00Z'
          },
          {
            id: '9',
            title: 'Birthday Surprise Setup',
            description: 'Special surprise decoration for a landmark birthday',
            image_url: 'https://images.pexels.com/photos/11044556/pexels-photo-11044556.jpeg',
            category: 'birthday',
            tags: ['birthday', 'surprise', 'special'],
            created_at: '2022-12-15T20:00:00Z'
          }
        ];
        
        setItems(fallbackData);
        setFilteredItems(fallbackData);
      } finally {
        setLoading(false);
      }
    };
    
    fetchGallery();
  }, []);
  
  // Handle category filter change
  useEffect(() => {
    if (selectedCategory === 'all') {
      setFilteredItems(items);
    } else {
      setFilteredItems(items.filter(item => item.category === selectedCategory));
    }
  }, [selectedCategory, items]);
  
  // Handle modal open
  const openModal = (item: GalleryItem) => {
    setSelectedItem(item);
    document.body.style.overflow = 'hidden';
  };
  
  // Handle modal close
  const closeModal = () => {
    setSelectedItem(null);
    document.body.style.overflow = 'auto';
  };

  return (
    <div className="min-h-screen bg-cream py-16">
      <div className="container mx-auto px-4">
        <h1 className="section-title text-center">Our Gallery</h1>
        <p className="section-subtitle text-center">
          Explore our past work and get inspired for your next event
        </p>
        
        {/* Category filters */}
        <div className="flex flex-wrap justify-center gap-2 md:gap-4 mb-8">
          {categories.map((category) => (
            <button
              key={category.id}
              onClick={() => setSelectedCategory(category.id)}
              className={`px-4 py-2 rounded-full text-sm md:text-base transition ${
                selectedCategory === category.id
                  ? 'bg-maroon text-white'
                  : 'bg-white text-gray-700 hover:bg-gray-100'
              }`}
            >
              {category.name}
            </button>
          ))}
        </div>
        
        {/* Gallery grid */}
        {loading ? (
          <div className="flex justify-center items-center py-20">
            <div className="w-12 h-12 border-4 border-t-maroon rounded-full animate-spin"></div>
          </div>
        ) : filteredItems.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-xl text-gray-600">No items found in this category</p>
          </div>
        ) : (
          <motion.div 
            layout
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6"
          >
            {filteredItems.map((item) => (
              <motion.div
                key={item.id}
                layout
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.5 }}
                className="gallery-item cursor-pointer rounded-lg overflow-hidden shadow-md"
                onClick={() => openModal(item)}
              >
                <img 
                  src={item.image_url} 
                  alt={item.title} 
                  className="w-full h-64 object-cover"
                />
                <div className="gallery-overlay flex flex-col justify-center items-center text-center p-4">
                  <h3 className="text-xl font-semibold text-white mb-2">{item.title}</h3>
                  {item.description && (
                    <p className="text-white/90 mb-3 text-sm">{item.description}</p>
                  )}
                  <span className="text-white/80 text-sm bg-maroon/80 px-3 py-1 rounded-full">
                    {item.category.charAt(0).toUpperCase() + item.category.slice(1)}
                  </span>
                </div>
              </motion.div>
            ))}
          </motion.div>
        )}
      </div>
      
      {/* Modal */}
      {selectedItem && (
        <div 
          className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4"
          onClick={closeModal}
        >
          <div 
            className="bg-white rounded-lg overflow-hidden max-w-4xl w-full max-h-[90vh] flex flex-col"
            onClick={e => e.stopPropagation()}
          >
            <div className="relative h-[50vh]">
              <img 
                src={selectedItem.image_url}
                alt={selectedItem.title}
                className="w-full h-full object-cover"
              />
              <button 
                className="absolute top-4 right-4 bg-white/80 rounded-full p-2 text-gray-800 hover:bg-white"
                onClick={closeModal}
              >
                &times;
              </button>
            </div>
            <div className="p-6">
              <h3 className="text-2xl font-semibold mb-2">{selectedItem.title}</h3>
              {selectedItem.description && (
                <p className="text-gray-600 mb-4">{selectedItem.description}</p>
              )}
              <div className="flex flex-wrap gap-2 mb-4">
                {selectedItem.tags?.map((tag, index) => (
                  <span 
                    key={index}
                    className="bg-gray-100 text-gray-600 px-3 py-1 rounded-full text-sm"
                  >
                    #{tag}
                  </span>
                ))}
              </div>
              <div className="flex justify-between items-center">
                <span className="bg-maroon text-white px-3 py-1 rounded-full text-sm">
                  {selectedItem.category.charAt(0).toUpperCase() + selectedItem.category.slice(1)}
                </span>
                <span className="text-sm text-gray-500">
                  {new Date(selectedItem.created_at).toLocaleDateString('en-US', {
                    year: 'numeric',
                    month: 'long'
                  })}
                </span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Gallery;