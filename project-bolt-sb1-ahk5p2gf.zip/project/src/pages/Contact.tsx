import { useState } from 'react';
import { motion } from 'framer-motion';
import { supabase } from '../lib/supabase';
import { toast } from 'sonner';
import { 
  Mail, 
  Phone, 
  MapPin, 
  Clock, 
  Facebook, 
  Instagram, 
  Send 
} from 'lucide-react';
import { useUser } from '../contexts/UserContext';

interface ContactFormData {
  name: string;
  email: string;
  phone: string;
  subject: string;
  message: string;
}

const Contact = () => {
  const { user } = useUser();
  
  const [formData, setFormData] = useState<ContactFormData>({
    name: '',
    email: user?.email || '',
    phone: '',
    subject: '',
    message: ''
  });
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Basic validation
    if (!formData.name || !formData.email || !formData.phone || !formData.message) {
      toast.error('Please fill in all required fields');
      return;
    }
    
    setLoading(true);
    
    try {
      // In a real implementation, this would save to the database
      // For now, we'll simulate a successful submission
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Reset form and show success message
      setFormData({
        name: '',
        email: '',
        phone: '',
        subject: '',
        message: ''
      });
      setSuccess(true);
      toast.success('Your message has been sent successfully!');
      
    } catch (error) {
      console.error('Error submitting form:', error);
      toast.error('There was an error sending your message. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-cream py-16">
      <div className="container mx-auto px-4">
        <h1 className="section-title text-center">Contact Us</h1>
        <p className="section-subtitle text-center">
          Get in touch with us for any inquiries or to book our services
        </p>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 mt-12">
          {/* Contact Form */}
          <motion.div 
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
            className="bg-white rounded-lg shadow-md p-6 md:p-8"
          >
            <h2 className="text-2xl font-semibold mb-6">Send us a Message</h2>
            
            {success ? (
              <div className="bg-green-50 border border-green-200 text-green-700 p-4 rounded-md mb-6">
                <h3 className="text-lg font-semibold mb-2">Thank You!</h3>
                <p>Your message has been sent successfully. We'll get back to you as soon as possible.</p>
                <button 
                  onClick={() => setSuccess(false)}
                  className="mt-4 text-maroon font-medium hover:underline"
                >
                  Send another message
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit}>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                  <div>
                    <label htmlFor="name" className="block text-gray-700 text-sm font-medium mb-2">
                      Full Name <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      placeholder="John Doe"
                      value={formData.name}
                      onChange={handleChange}
                      className="input-field"
                      required
                    />
                  </div>
                  <div>
                    <label htmlFor="email" className="block text-gray-700 text-sm font-medium mb-2">
                      Email Address <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      placeholder="you@example.com"
                      value={formData.email}
                      onChange={handleChange}
                      className="input-field"
                      required
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                  <div>
                    <label htmlFor="phone" className="block text-gray-700 text-sm font-medium mb-2">
                      Phone Number <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="tel"
                      id="phone"
                      name="phone"
                      placeholder="+91 1234567890"
                      value={formData.phone}
                      onChange={handleChange}
                      className="input-field"
                      required
                    />
                  </div>
                  <div>
                    <label htmlFor="subject" className="block text-gray-700 text-sm font-medium mb-2">
                      Subject
                    </label>
                    <select
                      id="subject"
                      name="subject"
                      value={formData.subject}
                      onChange={handleChange}
                      className="input-field"
                    >
                      <option value="">Select a subject</option>
                      <option value="Booking Inquiry">Booking Inquiry</option>
                      <option value="Price Quote">Price Quote</option>
                      <option value="Wedding Package">Wedding Package</option>
                      <option value="Corporate Event">Corporate Event</option>
                      <option value="Birthday Party">Birthday Party</option>
                      <option value="Other">Other</option>
                    </select>
                  </div>
                </div>
                
                <div className="mb-6">
                  <label htmlFor="message" className="block text-gray-700 text-sm font-medium mb-2">
                    Message <span className="text-red-500">*</span>
                  </label>
                  <textarea
                    id="message"
                    name="message"
                    rows={5}
                    placeholder="Tell us about your requirements..."
                    value={formData.message}
                    onChange={handleChange}
                    className="input-field"
                    required
                  />
                </div>
                
                <button
                  type="submit"
                  className="btn-primary w-full flex items-center justify-center"
                  disabled={loading}
                >
                  {loading ? (
                    <span className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></span>
                  ) : (
                    <Send size={18} className="mr-2" />
                  )}
                  Send Message
                </button>
              </form>
            )}
          </motion.div>
          
          {/* Contact Information */}
          <motion.div 
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="bg-maroon text-white rounded-lg shadow-md p-6 md:p-8 mb-8">
              <h2 className="text-2xl font-semibold mb-6">Contact Information</h2>
              
              <ul className="space-y-6">
                <li className="flex">
                  <MapPin size={24} className="text-gold flex-shrink-0 mr-4" />
                  <div>
                    <h3 className="font-semibold mb-1">Address</h3>
                    <p>123 Market Street, New Delhi - 110001, India</p>
                  </div>
                </li>
                
                <li className="flex">
                  <Phone size={24} className="text-gold flex-shrink-0 mr-4" />
                  <div>
                    <h3 className="font-semibold mb-1">Phone</h3>
                    <a href="tel:+911234567890" className="block hover:text-gold transition">
                      +91 123 456 7890
                    </a>
                    <a href="tel:+911234567891" className="block hover:text-gold transition">
                      +91 123 456 7891
                    </a>
                  </div>
                </li>
                
                <li className="flex">
                  <Mail size={24} className="text-gold flex-shrink-0 mr-4" />
                  <div>
                    <h3 className="font-semibold mb-1">Email</h3>
                    <a href="mailto:info@newsonia.com" className="block hover:text-gold transition">
                      info@newsonia.com
                    </a>
                    <a href="mailto:bookings@newsonia.com" className="block hover:text-gold transition">
                      bookings@newsonia.com
                    </a>
                  </div>
                </li>
                
                <li className="flex">
                  <Clock size={24} className="text-gold flex-shrink-0 mr-4" />
                  <div>
                    <h3 className="font-semibold mb-1">Working Hours</h3>
                    <p>Monday - Saturday: 10:00 AM - 8:00 PM</p>
                    <p>Sunday: Closed</p>
                  </div>
                </li>
              </ul>
              
              <div className="mt-8 pt-6 border-t border-maroon-700">
                <h3 className="font-semibold mb-3">Connect With Us</h3>
                <div className="flex space-x-4">
                  <a 
                    href="https://facebook.com" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="bg-white text-maroon h-10 w-10 rounded-full flex items-center justify-center hover:bg-gold hover:text-white transition"
                  >
                    <Facebook size={20} />
                  </a>
                  <a 
                    href="https://instagram.com" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="bg-white text-maroon h-10 w-10 rounded-full flex items-center justify-center hover:bg-gold hover:text-white transition"
                  >
                    <Instagram size={20} />
                  </a>
                  <a 
                    href="mailto:info@newsonia.com"
                    className="bg-white text-maroon h-10 w-10 rounded-full flex items-center justify-center hover:bg-gold hover:text-white transition"
                  >
                    <Mail size={20} />
                  </a>
                </div>
              </div>
            </div>
            
            {/* Map */}
            <div className="bg-white rounded-lg shadow-md p-6 md:p-8">
              <h2 className="text-2xl font-semibold mb-6">Our Location</h2>
              <div className="h-64 bg-gray-200 rounded-md overflow-hidden">
                <iframe 
                  title="New Sonia Tent House Location"
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3501.9272603173487!2d77.22561311492536!3d28.63294538241931!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390cfd32e5c97d5f%3A0x4845dafc79ac8b14!2sConnaught%20Place%2C%20New%20Delhi%2C%20Delhi%20110001!5e0!3m2!1sen!2sin!4v1625812345678!5m2!1sen!2sin" 
                  width="100%" 
                  height="100%" 
                  style={{ border: 0 }} 
                  allowFullScreen={true} 
                  loading="lazy" 
                />
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default Contact;